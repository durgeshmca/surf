-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 16, 2018 at 07:54 PM
-- Server version: 5.7.21-0ubuntu0.16.04.1
-- PHP Version: 5.6.34-1+ubuntu16.04.1+deb.sury.org+1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `surface`
--

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `user_name` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `name`, `user_name`, `email`, `mobile`, `password`) VALUES
(1, 'John Doe', 'admin', 'durgeshchandra.mishra@appinventiv.com', '9811167005', 'e19d5cd5af0378da05f63f891c7467af');

-- --------------------------------------------------------

--
-- Table structure for table `otp_master`
--

CREATE TABLE `otp_master` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `otp` varchar(10) NOT NULL,
  `mobile_no` varchar(15) NOT NULL,
  `otp_type` int(11) NOT NULL COMMENT '1: mobile 2: email 3: both 4: others',
  `created_at` datetime NOT NULL,
  `validity` datetime NOT NULL,
  `verify_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='otp master table';

--
-- Dumping data for table `otp_master`
--

INSERT INTO `otp_master` (`id`, `user_id`, `otp`, `mobile_no`, `otp_type`, `created_at`, `validity`, `verify_status`) VALUES
(1, 2, 'V1JTZK', '9811167006', 0, '2018-03-08 19:38:58', '2018-03-08 19:48:58', 0),
(2, 2, 'aYNKB6', '9811167006', 0, '2018-03-09 10:12:39', '2018-03-09 10:22:39', 0),
(3, 2, 'wyqOWu', '9811167006', 0, '2018-03-09 11:03:13', '2018-03-09 11:20:58', 0),
(4, 2, '89mNJL', '9811167006', 0, '2018-03-09 11:03:29', '2018-03-09 11:13:29', 0),
(5, 2, '798evA', '9811167006', 0, '2018-03-09 11:03:37', '2018-03-09 11:13:37', 0),
(6, 2, '1qPS9F', '9811167006', 0, '2018-03-09 11:07:08', '2018-03-09 11:17:08', 0),
(7, 2, 'nuPTbt', '9811167006', 0, '2018-03-09 11:11:07', '2018-03-09 11:21:20', 0),
(8, 2, '123456', '9811167006', 0, '2018-03-09 11:14:07', '2018-03-09 11:24:22', 0),
(9, 2, '123456', '9811167006', 0, '2018-03-09 11:57:51', '2018-03-09 12:07:51', 1),
(10, 2, '123456', '9811167006', 0, '2018-03-09 13:17:03', '2018-03-09 13:27:03', 0),
(11, 2, '123456', '9811167006', 0, '2018-03-09 13:18:36', '2018-03-09 13:28:36', 0),
(12, 2, '123456', '9811167006', 0, '2018-03-09 13:19:00', '2018-03-09 13:29:00', 0),
(13, 4, '123456', '98111670006', 0, '2018-03-09 13:29:46', '2018-03-09 13:43:22', 0),
(14, 4, '123456', '98111670006', 0, '2018-03-12 14:52:27', '2018-03-12 15:02:27', 0),
(15, 4, '123456', '98111670006', 0, '2018-03-12 14:53:37', '2018-03-12 15:03:37', 0),
(16, 4, 'Njxddk', '98111670006', 0, '2018-03-12 14:57:23', '2018-03-12 15:07:23', 0),
(17, 4, '123456', '98111670006', 0, '2018-03-12 14:58:01', '2018-03-12 15:08:01', 0),
(18, 20, '1234', '98585384478', 0, '2018-03-13 11:44:26', '2018-03-13 11:54:26', 1),
(19, 26, '1234', '9450590015', 3, '2018-03-13 18:50:48', '2018-03-13 19:00:48', 0),
(20, 27, '1234', '93141670006', 3, '2018-03-13 18:54:45', '2018-03-13 19:04:45', 0),
(21, 28, '1234', '93141676006', 3, '2018-03-13 19:00:36', '2018-03-13 19:10:36', 0),
(22, 1, '1234', '9811167005', 4, '2018-03-14 11:15:35', '2018-03-14 11:25:35', 1);

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(11) NOT NULL COMMENT 'post id',
  `user_id` int(11) NOT NULL COMMENT 'user_id of the user',
  `user_name` varchar(100) NOT NULL,
  `description` varchar(250) DEFAULT NULL,
  `media_type` varchar(50) DEFAULT NULL COMMENT 'Type 1:Image 2:vedio',
  `media` mediumtext,
  `thumbnail` text,
  `location` varchar(200) DEFAULT NULL,
  `longitude` varchar(100) DEFAULT NULL,
  `lattitude` varchar(100) DEFAULT NULL,
  `tags` text,
  `views_count` int(11) DEFAULT '0',
  `comments_count` int(11) DEFAULT '0',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `user_id`, `user_name`, `description`, `media_type`, `media`, `thumbnail`, `location`, `longitude`, `lattitude`, `tags`, `views_count`, `comments_count`, `created_at`, `updated_at`) VALUES
(5, 28, 'x3y311', 'A sample post', NULL, '[{"type":"1","url":"http:\\/\\/xyz.com\\/image\\/image.png","thumbnail":"http:\\/\\/xyz.com\\/image\\/image_thumb.png"},{"type":"2","url":"http:\\/\\/xyz.com\\/image\\/vedio.mp4","thumbnail":"http:\\/\\/xyz.com\\/image\\/vedio_thumb.png"}]', NULL, 'Washinton', '12133242356.646', '89126476752.353', '123,243,120', 0, 0, '2018-03-15 13:39:19', '2018-03-15 13:39:19'),
(6, 28, 'x3y311', 'A sample post', NULL, '[{"type":"1","url":"http:\\/\\/xyz.com\\/image\\/image.png","thumbnail":"http:\\/\\/xyz.com\\/image\\/image_thumb.png"},{"type":"2","url":"http:\\/\\/xyz.com\\/image\\/vedio.mp4","thumbnail":"http:\\/\\/xyz.com\\/image\\/vedio_thumb.png"}]', NULL, 'Washinton', '12133242356.646', '89126476752.353', '123,243,120', 0, 0, '2018-03-15 13:39:19', '2018-03-15 13:39:19'),
(7, 28, 'x3y311', 'A sample post', NULL, '[{"type":"1","url":"http:\\/\\/xyz.com\\/image\\/image.png","thumbnail":"http:\\/\\/xyz.com\\/image\\/image_thumb.png"},{"type":"2","url":"http:\\/\\/xyz.com\\/image\\/vedio.mp4","thumbnail":"http:\\/\\/xyz.com\\/image\\/vedio_thumb.png"}]', NULL, 'Washinton', '12133242356.646', '89126476752.353', '123,243,120', 0, 0, '2018-03-15 13:39:20', '2018-03-15 13:39:20'),
(8, 28, 'x3y311', 'A sample post', NULL, '[{"type":"1","url":"http:\\/\\/xyz.com\\/image\\/image.png","thumbnail":"http:\\/\\/xyz.com\\/image\\/image_thumb.png"},{"type":"2","url":"http:\\/\\/xyz.com\\/image\\/vedio.mp4","thumbnail":"http:\\/\\/xyz.com\\/image\\/vedio_thumb.png"}]', NULL, 'Washinton', '12133242356.646', '89126476752.353', '123,243,120', 0, 0, '2018-03-15 13:39:21', '2018-03-15 13:39:21'),
(9, 28, 'x3y311', 'A sample post', NULL, '[{"type":"1","url":"http:\\/\\/xyz.com\\/image\\/image.png","thumbnail":"http:\\/\\/xyz.com\\/image\\/image_thumb.png"},{"type":"2","url":"http:\\/\\/xyz.com\\/image\\/vedio.mp4","thumbnail":"http:\\/\\/xyz.com\\/image\\/vedio_thumb.png"}]', NULL, 'Washinton', '12133242356.646', '89126476752.353', '123,243,120', 0, 0, '2018-03-15 13:39:22', '2018-03-15 13:39:22'),
(10, 28, 'x3y311', 'A sample post', NULL, '[{"type":"1","url":"http:\\/\\/xyz.com\\/image\\/image.png","thumbnail":"http:\\/\\/xyz.com\\/image\\/image_thumb.png"},{"type":"2","url":"http:\\/\\/xyz.com\\/image\\/vedio.mp4","thumbnail":"http:\\/\\/xyz.com\\/image\\/vedio_thumb.png"}]', NULL, 'Washinton', '12133242356.646', '89126476752.353', '123,243,120', 0, 0, '2018-03-15 13:39:23', '2018-03-15 13:39:23'),
(11, 28, 'x3y311', 'A sample post', NULL, '[{"type":"1","url":"http:\\/\\/xyz.com\\/image\\/image.png","thumbnail":"http:\\/\\/xyz.com\\/image\\/image_thumb.png"},{"type":"2","url":"http:\\/\\/xyz.com\\/image\\/vedio.mp4","thumbnail":"http:\\/\\/xyz.com\\/image\\/vedio_thumb.png"}]', NULL, 'Washinton', '12133242356.646', '89126476752.353', '123,243,120', 0, 0, '2018-03-15 13:39:23', '2018-03-15 13:39:23'),
(12, 28, 'x3y311', 'A sample post', NULL, '[{"type":"1","url":"http:\\/\\/xyz.com\\/image\\/image.png","thumbnail":"http:\\/\\/xyz.com\\/image\\/image_thumb.png"},{"type":"2","url":"http:\\/\\/xyz.com\\/image\\/vedio.mp4","thumbnail":"http:\\/\\/xyz.com\\/image\\/vedio_thumb.png"}]', NULL, 'Washinton', '12133242356.646', '89126476752.353', '123,243,120', 0, 0, '2018-03-15 13:39:24', '2018-03-15 13:39:24'),
(13, 28, 'x3y311', 'A sample post', NULL, '[{"type":"1","url":"http:\\/\\/xyz.com\\/image\\/image.png","thumbnail":"http:\\/\\/xyz.com\\/image\\/image_thumb.png"},{"type":"2","url":"http:\\/\\/xyz.com\\/image\\/vedio.mp4","thumbnail":"http:\\/\\/xyz.com\\/image\\/vedio_thumb.png"}]', NULL, 'Washinton', '12133242356.646', '89126476752.353', '123,243,120', 0, 0, '2018-03-15 13:39:24', '2018-03-15 13:39:24'),
(14, 28, 'x3y311', 'A sample post', NULL, '[{"type":"1","url":"http:\\/\\/xyz.com\\/image\\/image.png","thumbnail":"http:\\/\\/xyz.com\\/image\\/image_thumb.png"},{"type":"2","url":"http:\\/\\/xyz.com\\/image\\/vedio.mp4","thumbnail":"http:\\/\\/xyz.com\\/image\\/vedio_thumb.png"}]', NULL, 'Washinton', '12133242356.646', '89126476752.353', '123,243,120', 0, 0, '2018-03-15 13:39:24', '2018-03-15 13:39:24'),
(15, 28, 'x3y311', 'A sample post', NULL, '[{"type":"1","url":"http:\\/\\/xyz.com\\/image\\/image.png","thumbnail":"http:\\/\\/xyz.com\\/image\\/image_thumb.png"},{"type":"2","url":"http:\\/\\/xyz.com\\/image\\/vedio.mp4","thumbnail":"http:\\/\\/xyz.com\\/image\\/vedio_thumb.png"}]', NULL, 'Washinton', '12133242356.646', '89126476752.353', '123,243,120', 0, 0, '2018-03-15 13:39:25', '2018-03-15 13:39:25'),
(16, 28, 'x3y311', 'A sample post', NULL, '[{"type":"1","url":"http:\\/\\/xyz.com\\/image\\/image.png","thumbnail":"http:\\/\\/xyz.com\\/image\\/image_thumb.png"},{"type":"2","url":"http:\\/\\/xyz.com\\/image\\/vedio.mp4","thumbnail":"http:\\/\\/xyz.com\\/image\\/vedio_thumb.png"}]', NULL, 'Washinton', '12133242356.646', '89126476752.353', '123,243,120', 0, 0, '2018-03-15 13:39:25', '2018-03-15 13:39:25'),
(17, 28, 'x3y311', 'A sample post', NULL, '[{"type":"1","url":"http:\\/\\/xyz.com\\/image\\/image.png","thumbnail":"http:\\/\\/xyz.com\\/image\\/image_thumb.png"},{"type":"2","url":"http:\\/\\/xyz.com\\/image\\/vedio.mp4","thumbnail":"http:\\/\\/xyz.com\\/image\\/vedio_thumb.png"}]', NULL, 'Washinton', '12133242356.646', '89126476752.353', '123,243,120', 0, 0, '2018-03-15 13:39:25', '2018-03-15 13:39:25'),
(18, 28, 'x3y311', 'A sample post', NULL, '[{"type":"1","url":"http:\\/\\/xyz.com\\/image\\/image.png","thumbnail":"http:\\/\\/xyz.com\\/image\\/image_thumb.png"},{"type":"2","url":"http:\\/\\/xyz.com\\/image\\/vedio.mp4","thumbnail":"http:\\/\\/xyz.com\\/image\\/vedio_thumb.png"}]', NULL, 'Washinton', '12133242356.646', '89126476752.353', '123,243,120', 0, 0, '2018-03-15 13:39:26', '2018-03-15 13:39:26'),
(19, 28, 'x3y311', 'A sample post', NULL, '[{"type":"1","url":"http:\\/\\/xyz.com\\/image\\/image.png","thumbnail":"http:\\/\\/xyz.com\\/image\\/image_thumb.png"},{"type":"2","url":"http:\\/\\/xyz.com\\/image\\/vedio.mp4","thumbnail":"http:\\/\\/xyz.com\\/image\\/vedio_thumb.png"}]', NULL, 'Washinton', '12133242356.646', '89126476752.353', '123,243,120', 0, 0, '2018-03-15 13:39:26', '2018-03-15 13:39:26'),
(20, 28, 'x3y311', 'A sample post', NULL, '[{"type":"1","url":"http:\\/\\/xyz.com\\/image\\/image.png","thumbnail":"http:\\/\\/xyz.com\\/image\\/image_thumb.png"},{"type":"2","url":"http:\\/\\/xyz.com\\/image\\/vedio.mp4","thumbnail":"http:\\/\\/xyz.com\\/image\\/vedio_thumb.png"}]', NULL, 'Washinton', '12133242356.646', '89126476752.353', '123,243,120', 0, 0, '2018-03-15 13:39:26', '2018-03-15 13:39:26'),
(22, 28, 'x3y311', 'A sample post', NULL, '[{"type":"1","url":"http:\\/\\/xyz.com\\/image\\/image.png","thumbnail":"http:\\/\\/xyz.com\\/image\\/image_thumb.png"},{"type":"2","url":"http:\\/\\/xyz.com\\/image\\/vedio.mp4","thumbnail":"http:\\/\\/xyz.com\\/image\\/vedio_thumb.png"}]', NULL, 'Washinton', '12133242356.646', '89126476752.353', '123,243,120', 0, 0, '2018-03-15 13:39:27', '2018-03-15 13:39:27'),
(23, 28, 'x3y311', 'A sample post', NULL, '[{"type":"1","url":"http:\\/\\/xyz.com\\/image\\/image.png","thumbnail":"http:\\/\\/xyz.com\\/image\\/image_thumb.png"},{"type":"2","url":"http:\\/\\/xyz.com\\/image\\/vedio.mp4","thumbnail":"http:\\/\\/xyz.com\\/image\\/vedio_thumb.png"}]', NULL, 'Washinton', '12133242356.646', '89126476752.353', '123,243,120', 0, 0, '2018-03-15 13:39:27', '2018-03-15 13:39:27'),
(24, 28, 'x3y311', 'A sample post', NULL, '[{"type":"1","url":"http:\\/\\/xyz.com\\/image\\/image.png","thumbnail":"http:\\/\\/xyz.com\\/image\\/image_thumb.png"},{"type":"2","url":"http:\\/\\/xyz.com\\/image\\/vedio.mp4","thumbnail":"http:\\/\\/xyz.com\\/image\\/vedio_thumb.png"}]', NULL, 'Washinton', '12133242356.646', '89126476752.353', '123,243,120', 0, 0, '2018-03-15 13:39:28', '2018-03-15 13:39:28'),
(25, 28, 'x3y311', 'A sample post', NULL, '[{"type":"1","url":"http:\\/\\/xyz.com\\/image\\/image.png","thumbnail":"http:\\/\\/xyz.com\\/image\\/image_thumb.png"},{"type":"2","url":"http:\\/\\/xyz.com\\/image\\/vedio.mp4","thumbnail":"http:\\/\\/xyz.com\\/image\\/vedio_thumb.png"}]', NULL, 'Washinton', '12133242356.646', '89126476752.353', '123,243,120', 0, 0, '2018-03-15 13:39:28', '2018-03-15 13:39:28'),
(26, 28, 'x3y311', 'A sample post', NULL, '[{"type":"1","url":"http:\\/\\/xyz.com\\/image\\/image.png","thumbnail":"http:\\/\\/xyz.com\\/image\\/image_thumb.png"},{"type":"2","url":"http:\\/\\/xyz.com\\/image\\/vedio.mp4","thumbnail":"http:\\/\\/xyz.com\\/image\\/vedio_thumb.png"}]', NULL, 'Washinton', '12133242356.646', '89126476752.353', '123,243,120', 0, 0, '2018-03-15 13:39:28', '2018-03-15 13:39:28'),
(27, 28, 'x3y311', 'A sample post', NULL, '[{"type":"1","url":"http:\\/\\/xyz.com\\/image\\/image.png","thumbnail":"http:\\/\\/xyz.com\\/image\\/image_thumb.png"},{"type":"2","url":"http:\\/\\/xyz.com\\/image\\/vedio.mp4","thumbnail":"http:\\/\\/xyz.com\\/image\\/vedio_thumb.png"}]', NULL, 'Washinton', '12133242356.646', '89126476752.353', '123,243,120', 0, 0, '2018-03-15 13:39:28', '2018-03-15 13:39:28'),
(28, 28, 'x3y311', 'A sample post', NULL, '[{"type":"1","url":"http:\\/\\/xyz.com\\/image\\/image.png","thumbnail":"http:\\/\\/xyz.com\\/image\\/image_thumb.png"},{"type":"2","url":"http:\\/\\/xyz.com\\/image\\/vedio.mp4","thumbnail":"http:\\/\\/xyz.com\\/image\\/vedio_thumb.png"}]', NULL, 'Washinton', '12133242356.646', '89126476752.353', '123,243,120', 0, 0, '2018-03-15 13:39:29', '2018-03-15 13:39:29');

-- --------------------------------------------------------

--
-- Table structure for table `Users`
--

CREATE TABLE `Users` (
  `user_id` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1' COMMENT '1: active 0:inactive',
  `name` varchar(50) NOT NULL,
  `user_name` varchar(30) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `mobile` varchar(15) DEFAULT NULL,
  `country_code` varchar(5) DEFAULT NULL,
  `location` varchar(100) NOT NULL,
  `access_key` varchar(100) DEFAULT NULL,
  `provider` varchar(10) NOT NULL DEFAULT '''app''',
  `provider_uid` varchar(100) DEFAULT NULL,
  `profile_image` varchar(250) DEFAULT NULL,
  `posts_count` int(11) NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Users`
--

INSERT INTO `Users` (`user_id`, `status`, `name`, `user_name`, `password`, `email`, `mobile`, `country_code`, `location`, `access_key`, `provider`, `provider_uid`, `profile_image`, `posts_count`, `created_at`, `updated_at`) VALUES
(1, 1, 'Durgesh', 'dcm', 'd16fb36f0911f878998c136191af705e', 'durgeshchandra.mishra@appinventiv.com', '9811167005', '91', 'NOIDA', '9G4EFf1kti4OavF4LtXaCoxgzP5BDwbM', 'facebook', '1234567890', NULL, 0, '2018-03-07 00:00:00', '2018-03-07 00:00:00'),
(26, 1, '', 'durxgyesh', 'e10adc3949ba59abbe56e057f20f883e', 'durgeshcmishra@gmail.com', '9450590015', '91', '', 'wW2ZwXxHTlwlWr7nKLWKMmt2fAzZrXk5', 'app', NULL, NULL, 0, '2018-03-13 18:50:48', '2018-03-13 18:50:48'),
(27, 1, '', 'x3y3zd11', 'd41d8cd98f00b204e9800998ecf8427e', 'durge3ssshhs@appinventiv.com', '93141670006', '91', '', 'HoVXoTna5Wl4g8lzlYJn61IqWPLhjNnW', 'facebook', '1234367804', NULL, 0, '2018-03-13 18:54:45', '2018-03-13 18:54:45'),
(28, 1, '', 'x3y311', 'd41d8cd98f00b204e9800998ecf8427e', 'durge3ss6hhs@appinventiv.com', '93141676006', '91', '', 'zJUek8cE8ElxZSiBax66PezchlT606x3', 'facebook', '1234347804', NULL, 0, '2018-03-13 19:00:36', '2018-03-13 19:00:36');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `otp_master`
--
ALTER TABLE `otp_master`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `Users`
--
ALTER TABLE `Users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `otp_master`
--
ALTER TABLE `otp_master`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'post id', AUTO_INCREMENT=29;
--
-- AUTO_INCREMENT for table `Users`
--
ALTER TABLE `Users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

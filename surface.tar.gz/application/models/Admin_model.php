<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_model extends CI_Model{

  public function __construct()
  {
    //parent::__construct();
    $this->load->database();
  }
  public function checkLogin($email,$password)
  {
    $this->db->where([
      'email'=>$email,
      'password' => md5($password)
    ]);
    $query = $this->db->get('login');
    if ($query->num_rows()>0) {
      return $query->row_object();
    }
    return false;
  }
  /****
  validate email of admin
  *******/
  public function getUserByEmail($email)
  {
    $this->db->select(['id','name','user_name','email','mobile']);
    $this->db->where('email',$email);
    $query = $this->db->get('login');
    if ($query->num_rows()>0) {
      return $query->row_array();
    }
    return false;
  }
  /****
  Update Admin password
  *****/
  public function updatePassword($id,$password)
  {
    $data['password'] = md5($password);
    $this->db->where('id',$id);
    if ($this->db->update('login',$data)) {
      return true;
    }
    return false;
  }
  /***
  method to list users with pagging
**********/
  public function listUsers($offset = 0,$limit = 20,$search='')
  {


    if (!empty($search)) {
      $this->db->like('name',$search)
                ->or_like('user_name',$search)
                ->or_like('email',$search);
      $data['total'] = $this->db->count_all_results('Users');
      $this->db->like('name',$search)
                ->or_like('user_name',$search)
                ->or_like('email',$search);
    }else{
      $data['total'] = $this->db->count_all('Users');
    }

    $this->db->limit($limit,$offset);
    $query = $this->db->get('Users');
    $data['data'] = $query->result_array();
    unset($data['data']['password']);
    unset($data['data']['access_key']);
    return $data;
  }
}

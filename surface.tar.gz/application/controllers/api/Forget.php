<?php
require APPPATH . 'libraries/REST_Controller.php';
/**********
  This controller class will handle forget password, username and reset passwords
******************/


class Forget extends REST_Controller {


	public function __construct()
  {
    parent::__construct();
    $this->load->helper('url_helper');
        }
  public function username_post()
  {
    $email = $this->post('email');
    $mobile = $this->post('mobile');
  }
}

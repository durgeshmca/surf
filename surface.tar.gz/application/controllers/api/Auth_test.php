<?php
require APPPATH . 'libraries/REST_Controller.php';
/**
 *
 */
class Auth_test extends REST_Controller
{

  function __construct()
  {
    parent::__construct();
    $this->load->library('authenticate');

  }
  public function index_get()
  {
    $this->authenticate->auth_check();
   return $this->response($this->get());
  }
}

<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Users extends CI_Controller {
  protected $user_data ;
  public function __construct()
  {

    parent::__construct();
     $this->load->model('admin_model');
     $this->load->library('auth_admin');
     $this->load->helper(['form','security']);
     $this->load->library('pagination');
     $this->user_data = $this->auth_admin->check_auth(); //checks and set user data
  }
  public function index($page = 1)
  {
    $page = xss_clean($page);
    $page = (int) $page;
    if ($page <=0 ) {
      $page = 1;
    }
    $limit = 2;
    $offset = ($page -1) * $limit;
    $users = $this->admin_model->listUsers($offset,$limit);
    $this->user_data['users'] = $users['data'];
    $this->user_data['users']['total'] = $users['total'];
    //pagging
    $config['base_url'] = site_url('/admin/users/index');
    $config['total_rows'] = $users['total'];
    $config['per_page'] = $limit ;
    $config['full_tag_open'] = "<ul>" ;
    $config['full_tag_close'] = "</ul>" ;
    $config['attributes'] = array('class' => 'page_cout');
    $config['current_tag_open'] = "<li class='page_cout active'>" ;
    $config['current_tag_close'] = "</li>" ;
    $this->pagination->initialize($config);
    $this->user_data['pagging'] = $this->pagination->create_links();

    $this->load->view('admin/users',$this->user_data);
  }
  /*******
  Method to view user's list from ajax
  **********/
  public function list_user($ppLimit = 10,$page = 1) //per page limit
  {
    $ppLimit = (int) $ppLimit;
    $ppLimit = ($ppLimit <= 0)? 10 : $ppLimit ;
    $page = (int) $page;
    $page = ($page <= 0)? 1 : $page ;
    if ($this->input->method() == 'post') {
      $search = $this->input->post('search');
      $search = xss_clean($search);
      $offset = ($page -1) * $ppLimit;
      $users = $this->admin_model->listUsers($offset,$ppLimit,$search);
      $config['base_url'] = 'javascript:void(0);';
      $config['total_rows'] = $users['total'];
      $config['per_page'] = $ppLimit ;
      $config['full_tag_open'] = '<div id="paginator">';
      $config['full_tag_close'] = '</div>';
      $config['uri_segment']=3;
      $config['use_page_numbers'] = TRUE;
      $config['attributes'] = array('class' => 'page_cout','onclick'=>'openPage();','data-id'=>'123');
      $config['current_tag_open'] = "<li class='page_cout active'>" ;
      $config['current_tag_close'] = "</li>" ;
      $this->pagination->initialize($config);
      $users['pagging'] = $this->pagination->create_links();

      //print_r($users);
      header("Content-Type: application/json");
      echo json_encode($users);
    }
  }

}

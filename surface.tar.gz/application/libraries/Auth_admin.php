<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
 *
 */
class Auth_admin
{
  protected $CI;
  function __construct()
  {
    $this->CI = &get_instance();
    $this->CI->load->library('session');
  }
  public function check_auth()
  {
    if (isset($_SESSION['user_data']) && $_SESSION['user_data']['id'] !='') {
      return $_SESSION['user_data'];
      //var_dump($_SESSION['user_data']); die;
    }
    redirect('/admin/login');
  }
}

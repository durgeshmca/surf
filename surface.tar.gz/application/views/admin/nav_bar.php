<!--Header-->
<header>
    <!--toggle button-->
    <div class="toggleBtn">
        <span class="line-bar"></span>
        <span class="line-bar shot-line-br"></span>
        <span class="line-bar"></span>
    </div>
    <!--toggle button close-->

    <!--nav brand wrap-->
    <div class="nav-brand clearfix">
        <a href="javascripit:void(0)" title="Logo">
            <!-- <span><img src="public/<?php echo base_url();?>public/images/"></span> -->
            <div class="logoTxt">
                <span class="logo_txt">Surface</span>
            </div>
        </a>
    </div>
    <!--nav brand wrap close-->
    <!--User Setting-->
    <div class="user-setting-wrap">
        <ul>
            <li class="drp">
                <a href="javascript:void(0)" class="drpactions dropmenu" data-toggle="dropdown" title="Notification">
                    <i class="fa fa-bell-o"></i>
                </a>
                <div class="fncy-drp fncy-dropdown-two">
                    <h3 class="notifyTxt">Notifications</h3>
                    <ul>
                        <li><a href="javascript:void(0)">Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</a></li>
                        <li><a href="javascript:void(0)">Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</a></li>
                        <li><a href="" class="viewallNotifications">View All Notifications</a></li>
                    </ul>
                </div>
            </li>
            <li>
                <a href="profile.html" title="Setting"><img src="<?php echo base_url();?>public/images/setting.svg" alt="setting"></a>
            </li>
            <li>
                <a href="javascript:void(0)" data-toggle="modal" data-target="#myModal-logout" title="Logout"><img src="<?php echo base_url();?>public/images/logout.svg" title="Logout"></a>
            </li>
        </ul>
    </div>
    <!--User Setting wrap close-->
</header>
<!-- header close -->

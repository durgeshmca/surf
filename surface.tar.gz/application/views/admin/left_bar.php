<body class="">
    <div class="in-data-wrap">
        <!--left panel-->
        <aside class="sidebar-wrapper">
            <div class="closeSidebar768">x</div>
            <div class="sidebar-menu">
                <div class="user-short-detail">
                    <div class="image-view-wrapper img-view80p img-viewbdr-radius">
                        <div id="lefft-logo" class="image-view img-view80" style="background:url('<?php echo base_url();?>public/images/user.svg')"></div>
                    </div>
                    <span class="user-name"><?php echo $name; ?></span>
                </div>
                <div class="left-menu side-panel">
                    <ul>
                        <li>
                            <a href="javascript:void(0);" class="active">
                                <span class="left_icon dash_1"></span>
                                <!-- <img src="<?php echo base_url();?>public/images/soccer-ball-in-front-of-the-arch.svg" alt="Gameplay"> -->
                                <span class="nav-txt">Users</span>
                            </a>
                        </li>
                        <li>
                            <a href="post.html">
                                <span class="left_icon dash_3"> </span>
                                <!-- <img src="<?php echo base_url();?>public/images/cms.svg" alt="Field"> -->
                                <span class="nav-txt">Posts</span>
                            </a>
                        </li>
                        <li>
                            <a href="content.html">
                                <span class="left_icon dash_4"></span>
                                <!-- <img src="<?php echo base_url();?>public/images/laptop.svg" alt="Device Management"> -->
                                <span class="nav-txt">Content</span>
                            </a>
                        </li>
                        <!-- <li>
                            <a href="manage_version.html">
                                <span class="left_icon dash_5"></span>

                                <span class="nav-txt">Manage Version</span>
                            </a>
                        </li> -->
                        <li>
                            <a href="Notification.html">
                                <span class="left_icon dash_6"></span>
                                <!-- <img src="<?php echo base_url();?>public/images/first-aid-kit.svg" alt="Emergency"> -->
                                <span class="nav-txt">Notifications</span>
                            </a>
                        </li>
                        <li class="drop_down_action">
                            <a href="javascript:void(0)">
                                <span class="left_icon dash_7"></span>
                                <!-- <img src="<?php echo base_url();?>public/images/notification.svg" alt="Notification"> -->
                                <span class="nav-txt">Reported Content</span><span class="inner_drop_menu"></span>
                            </a>

                            <ul class="drop_down_menu">
                                <li>
                                    <a href="reported.html">
                                        <span class="left_icon dash_1"></span>
                                        <span class="nav-txt">User</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="reported_post.html">
                                        <span class="left_icon dash_3"> </span>
                                        <span class="nav-txt">Posts</span>
                                    </a>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </div>
        </aside>
        <!--left panel-->

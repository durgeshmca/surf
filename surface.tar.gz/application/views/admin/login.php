<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0,
              minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>SurfaceApp</title>
    <!-- <link rel="icon" type="image/png" sizes="32x32" href="public/images/logo.png"> -->
    <link href='<?php echo base_url();?>public/css/plugin/bootstrap.min.css' rel='stylesheet'>
    <link href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.css' rel='stylesheet'>
    <link href='<?php echo base_url();?>public/css/style.css' rel='stylesheet'>
    <link href='<?php echo base_url();?>public/css/css/media.css' rel='stylesheet'>
</head>

<div class="form-section">
    <div class="form-inner-section">
        <div class="logo">
            <span class="logo_txt">Surface</span>
        </div>
        <div class="form-wrapper">
            <div class="login-error">
                <span class="error"><?php echo validation_errors(); if (isset($error)) {
                  echo $error;
                }?></span>
            </div>
            <div class="login-error">
                <span class=""><?php $msg = $this->session->flashdata('msg');
                  if(!empty($msg))
                    {
                      echo $msg;
                    }
  ?></span>
            </div>
            <!--<form action="<?php echo base_url()?>index.php/admin/login/makelogin" method="post"> -->
            <?php echo form_open('admin/login/makelogin'); ?>
                <h1 class="form-heading">Login</h1>
                <p class="form-desc">Enter Your Details below to get access your account</p>
                <div class="form-group">
                    <span class="field-ico user-ico"></span>
                    <input type="text" class="form-field" maxlength="40" placeholder="Email ID" name="email" value="<?php echo set_value('email'); ?>" autocomplete="off" />
                    <label class="login_error"></label>
                </div>
                <div class="form-group" id="passworderr">
                    <span class="field-ico password-ico"></span>
                    <input type="password" class="form-field" maxlength="20" placeholder="Password" name="password" value="" autocomplete="off" required />
                    <label class="login_error"></label>
                </div>
                <div class="form-group clearfix">
                    <label class="pull-right">
                        <a href="<?php echo site_url('/admin/login/forget_password')?>" class="frgt-pwd">Forgot Password?</a>
                    </label>
                </div>
                <div class="form-group text-center">
                    <button class="login-btn" type="submit" id="login" onclick="#window.location.href='User.html'">Login</button>
                </div>
            </form>

        </div>
    </div>
</div>
<!--Footer-->
<!--Login page  Wrap close-->
<script src="<?php echo base_url();?>public/js/jquery.min.js"></script>
<script src="<?php echo base_url();?>public/js/outer-common.js"></script>
<script src="<?php echo base_url();?>public/js/global-msg.js"></script>
<script src="<?php echo base_url();?>public/js/jquery.validate.min.js"></script>

</html>

<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_model extends CI_Model{

  public function __construct()
  {
    parent::__construct();
    $this->load->database();

  }

  /******************
  method to get user details based on user_id of the user

  ********************/
  public function getUserById($user_id)
  {
    $this->db->select(['user_id','name','user_name','email','mobile','country_code','provider','provider_uid','access_key','created_at','updated_at']);
    $this->db->where('user_id',$user_id);
    $query = $this->db->get('users');
  //  echo $this->db->last_query();
    if ($query->num_rows()> 0) {
      $data = $query->row_array();
      $data['access_token'] = $data['access_key'];
      return $data;
    } else {
      return false;
    }
  }
  /***********
  Method to update user's data it will recive user_id and data to update in an array
  */

/****************
  Method to logout user
*/
public function logout($user_id)
{
  if (!empty($user_id)) {
    $this->db->where('user_id',$user_id);
    $data = [
      'access_key' => ''
    ];
    if($this->db->update('users',$data)){
      return true;
    }
  }
  return false;
}
/******************
Method to update user profile or data
updateUser($userData['user_id'],['password'=>$password])
*****************/
public function updateUser($user_id,array $data)
{
  if (!empty($user_id)) {
    $this->db->where('user_id',$user_id);
    if($this->db->update('users',$data)){
      return true;
    }
  }
  return false;
}
/******************
method to get user details based on mobile of the user

********************/
public function getUserByMobile($mobile)
{
  $this->db->select(['user_id','name','user_name','email','mobile','country_code','provider','provider_uid','access_key','created_at','updated_at']);
  $this->db->where('mobile',$mobile);
  $query = $this->db->get('users');
//  echo $this->db->last_query();
  if ($query->num_rows()> 0) {
    $data = $query->row_array();
    $data['access_token'] = $data['access_key'];
    return $data;
  } else {
    return false;
  }
}
  /****Signup User***/
  public function addUser($data)
  {
    if ($this->db->insert('users',$data)) {
      $user_id = $this->db->insert_id();
      $this->db->insert('users_profile',[
        'user_id'=>$user_id
    ]);
    return $user_id;
    }
    return false;
  }
  /*********************
  Users Profile Listing

  *************************/
  public function getProfile($user_id)
  {
    $this->db->select(['users.user_id','user_name','profile_image','posts_count','dob','company','bio','weblink','friends','created_at','updated_at']);
    $this->db->from('users')
             ->join('users_profile','users.user_id = users_profile.user_id','left');
    $this->db->where('users.user_id',$user_id);
    $query = $this->db->get();
     //echo $this->db->last_query();
    if ($query->num_rows()>0) {
      return $query->row_array();
    }
    return false;
  }
 /*******
  update profile of a user
 **************/
  public function updateProfile($user_id,$data)
  {
    $whereArray = array();

    $this->db->where('user_id',$user_id);
    if (isset($data['profile_image'])) {
      $whereArray['profile_image'] = $data['profile_image'];
    }
    $whereArray['name']= $data['name'];
    $whereArray['user_name']= $data['user_name'];
    $whereArray['location']= $data['location'];
    if($this->db->update('users',$whereArray)){
    // echo $this->db->last_query();
    $whereArray = array();
    $whereArray['bio']= $data['bio'];
    $whereArray['gender']= $data['gender'];
    $whereArray['location']= $data['location'];
    $whereArray['longitude']= $data['longitude'];
    $whereArray['lattitude']= $data['lattitude'];
    $whereArray['weblink']= $data['links'];
    $this->db->where('user_id',$user_id);
    if($this->db->update('users_profile',$whereArray)){
      return true;
    }
  }
    //echo $this->db->last_query();
    return false;


  }
}

<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

  public function __construct()
  {
    parent::__construct();
    //$this->load->library("security");
     $this->load->helper(['form','send_mail','encrypt_decrypt']);
     $this->load->model('admin_model');
     $this->load->library('form_validation');
     $this->load->helper('security');
     $this->load->library('session');
  }
  public function index()
	{
		$this->load->view('admin/login');
	}
  public function makelogin()
  {
  //  print_r($this->input->post());
    //validate login Details
  $email =  filter_var($this->input->post('email'), FILTER_VALIDATE_EMAIL) ;
  $password =  $this->input->post('password');
  $this->form_validation->set_rules('email', 'Email', 'required|valid_email')
                        ->set_rules('password', 'Password', 'required');
  if ($this->form_validation->run() == FALSE)
    {
          $this->load->view('admin/login');
    }
      else
      {
          //check login credentials
          $loginData = $this->admin_model->checkLogin($email,$password);
        //set sessions then redirect to dashboard or users page

          //$this->load->view('admin/users');
          //var_dump($loginData);
          if ($loginData !== false) {
            $this->load->library('session');
            $newdata['user_data'] = array(
              'id' => $loginData->id,
              'name'  => $loginData->name,
              'email'     => $loginData->email,
              'mobile'     => $loginData->mobile,
              'user_name'     => $loginData->user_name,
              'profile_image'     => $loginData->profile_image

            );


            $_SESSION['user_data'] = $newdata['user_data'];
            $_SESSION['logged_in'] = TRUE;
            redirect('/admin/users');
          } else {
            $error['error'] = "Invalid Login Credentials.";
            $this->load->view('admin/login',$error);
          }

    }

  }
  /*
  Method to logout user

  ****************/
    public function logout()
    {

      $this->session->sess_destroy();
      redirect("/admin/login");
    }
    /********
    Method to send reset password link.
    it takes email check and then sends email.
    ****************/
    public function forget_password()
    {
      $errors =array();
      if ($this->input->method() == 'post') {
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
        if ($this->form_validation->run() != FALSE)
          {
                //check email in db
                $userData = $this->admin_model->getUserByEmail($this->input->post('email'));
                if(is_array($userData)){
                  //generate and send password reset link over email
                  $encryptString = $userData['id'].",".$userData['email'].",".time();
                  $encryptedData = encrypt_decrypt('encrypt',$encryptString);
                  $link = site_url('admin/login/reset_password/').$encryptedData;
                  $message = "Please click here to reset your password <a href='$link'><button>Reset Password</button></a>";
                  $subject = "Password Reset";
                  $to = $this->input->post('email');
                  sendMail($message,$subject,$to);
                  $errors['error'] = 'An Email has been sent with password reset link.';
                  $this->session->set_flashdata('msg',$errors['error']);
                  redirect("/admin/login");
                } else {
                  $errors['error'] = 'There is no user with this email id.';
                }
          }
      }
      $this->load->view('admin/forget_password',$errors);
    }
    /**********************
    Method to reset password
    decrypt data recieved and check validity for 10 minutes
    if all is valid then open password reset page. otherwise to forget password page
    ***************/
    public function reset_password($token)
    {
      $errors = array();
      $token = trim($token);
      $token = xss_clean($token);
      if ($this->input->method()=='post') {
        //validate password and confirm password
        $password = $this->input->post('password');
        $cpassword = $this->input->post('cpassword');
        $id = xss_clean($this->input->post('validity'));
        $this->form_validation->set_rules('password', 'Password', 'required|min_length[8]')
                              ->set_rules('cpassword', 'Confirm Password', 'required|matches[password]');
        if ($this->form_validation->run() != FALSE) {
          //now update password.
          $userId = encrypt_decrypt('decrypt',$id);
          if ($this->admin_model->updatePassword($userId,$password)) {
            $this->session->set_flashdata('msg','Password changed Successfully.');
            redirect('/admin/login');
          } else {
            $this->session->set_flashdata('msg','Password Could not be changed.');
          }
      //  }else {
          redirect('/admin/login/reset_password/'.$token);
        } else {
            $this->load->view('admin/reset_password',array('validity'=>$id,'token'=>$token));
            //redirect('/admin/login/reset_password/'.$token);
        }

      } else {

        if (!empty($token)) {
          $decryptedData = encrypt_decrypt('decrypt',$token);
          list($id,$email,$time) = explode(',',$decryptedData);
          $id = (int) $id;
          if (!empty($id) || !empty($email) || !empty($time)) {
            //check token validity
            if ($time >= time() - 2400) {
              //now load reset password view
              $encryptedId = encrypt_decrypt('encrypt',$id);
              $this->load->view('admin/reset_password',array('validity'=>$encryptedId,'token'=>$token));
              return;

            }else {
              $errors['error']='Link Expired.';
            }
          }
        }
        $this->load->view('admin/forget_password',$errors);
    }
  }

}

<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Profile extends CI_Controller {


  public function __construct()
  {
    parent::__construct();
    $this->load->library(['auth_admin']);
    $this->load->library(['form_validation','session']);
    $this->load->helper(['form','security']);
    $this->load->model('admin_model');
    $this->auth_admin->check_auth();
  }
  public function index()
  {
    $this->load->view('admin/profile');
  }
  public function change_password()
  {
    if ($this->input->method() == 'post') {
      //print_r($this->input->post());
      $oldp = $this->input->post('oldpassword');
      $newp = $this->input->post('password');
      $cnewp = $this->input->post('confirm_password');

      $this->form_validation->set_rules('oldpassword', 'Old Password', 'required')
                            ->set_rules('password', 'New Password', 'required|differs[oldpassword]|min_length[5]|max_length[12]')
                            ->set_rules('confirm_password', 'Confirm Password', 'required|matches[password]');
      if ($this->form_validation->run() !== FALSE)
        {
          $checkOld = $this->admin_model->checkLogin($_SESSION['user_data']['email'],$oldp);
          if ($checkOld) {
            $this->admin_model->changeAdminPassword($_SESSION['user_data']['id'],$oldp,$newp);
            $this->session->set_flashdata('msg','Password changed Successfully.');
            redirect('/admin/profile');
          } else {
            $this->session->set_flashdata('msg','Old Password is wrong.');
          }
          redirect('/admin/profile/change_password');
        }
    }
    $this->load->view('admin/change_password');
  }
  public function edit()
  {
    if ($this->input->method()=='post') {
      //print_r($this->input->post());
      //validate
      $this->form_validation->set_rules('name', 'Name', 'required|min_length[4]|max_length[50]')
                            ->set_rules('email', 'Email', 'required|valid_email|max_length[60]')
                            ->set_rules('mobile', 'Mobile', 'required|min_length[10]|max_length[15]');
    if ($this->form_validation->run() !== FALSE)
    {
      if (!empty($_FILES['admin_image']['name'])) {
        //upload admin image
        //print_r($_FILES);
        echo $config['upload_path']          = './uploads/';
        $config['allowed_types']        = 'gif|jpg|png';
        $config['max_size']             = 2048;
      //  $config['max_width']            = 1024;
      //  $config['max_height']           = 768;

        $this->load->library('upload', $config);

        if ( ! $this->upload->do_upload('admin_image'))
            {
                $error = array('error' => $this->upload->display_errors());
                //var_dump($error);
                $this->load->view('admin/edit_profile', $error);
            }
        else
          {
                $data = array('upload_data' => $this->upload->data());
                //$this->load->view('admin/edit_profile', $data);
                $adminProfile['profile_image'] = $data['upload_data']['file_name'];

          }
        }
        //Now update admin profile
        $adminProfile['email'] = $this->input->post('email');
        $adminProfile['name'] = $this->input->post('name');
        $adminProfile['mobile'] = $this->input->post('mobile');
        if ($this->admin_model->updateProfile($_SESSION['user_data']['id'],$adminProfile)) {
          $_SESSION['user_data']['name']= $adminProfile['name'];
          $_SESSION['user_data']['email']=  $adminProfile['email'];
          $_SESSION['user_data']['mobile']=  $adminProfile['mobile'];
          if(isset($adminProfile['profile_image'])){
            $_SESSION['user_data']['profile_image']= $adminProfile['profile_image'];
          }
          $this->session->set_flashdata('msg','Admin Profile Updated .');
          redirect("admin/profile");
        } else {
          $this->session->set_flashdata('msg','Some Error in updating profile .');
          $this->load->view('admin/edit_profile');
        }
      }
    }
      $this->load->view('admin/edit_profile');
    }


}

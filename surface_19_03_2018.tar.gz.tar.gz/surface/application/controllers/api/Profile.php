<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require APPPATH . 'libraries/REST_Controller.php';
/*
This class is responsible to add / edit users profile as well as view other users profile
This will only be available to authenticated users
*******/
class Profile extends REST_Controller{
  private $user_id; //user_id of the user using the class it is mandatory
  public function __construct()
  {
    parent::__construct();
    //load auth library
    $this->load->library('authenticate');
    $this->user_id = $this->authenticate->auth_check();
    $this->load->model('user_model');
    $this->load->model('post_model');

  }
  /****
  Method to get profile of self as well as a user
  if user id is present in query then it will revert with user having that id


  *********************/
  public function view_get()
  {
    $response['status'] = FALSE;
    $user_id = $this->get('id');
    $user_id = (int) $user_id;
    if ($user_id && $user_id > 0) {
      //get profile of the user with user_id
      $profileData = $this->user_model->getProfile($user_id);
    } else {
      //get self profile
      $profileData = $this->user_model->getProfile($this->user_id);
    }
      //var_dump($profileData);
      //substr_count($value['tags'], ',')
      if (is_array($profileData)) {
        $profileData['friends'] = substr_count($profileData['friends'], ',');
        $response['status'] = true;
        $response['code'] = 200;
        $response['msg'] = 'Profile Data';
        $response['data'] = $profileData;
        return $this->response($response,$response['code']);
      } else {
        $response['code'] = 404;
        $response['msg'] = 'Profile Not Found';
        return $this->response($response,$response['code']);
      }


  }

  /************
  Method to update profile
  **********************/
  public function update_post()
  {
    //print_r($this->post());
    $response['status'] = FALSE;
    $data['profile_image'] = $this->post('profile_image');
    if ($data['profile_image']== NULL) {
      unset($data['profile_image']);
    }
    $data['name'] = $this->post('name');
    $data['user_name'] = $this->post('user_name');
    $data['bio'] = $this->post('bio');
    $data['gender'] = $this->post('gender');
    $data['location'] = $this->post('location');
    $data['longitude'] = $this->post('longitude');
    $data['lattitude'] = $this->post('lattitude');
    $data['links'] = $this->post('links');
    if (count($data['links'])>0) {
      $data['links'] = implode(',',$data['links']);
    }else {
      $data['links'] = '';
    }
    if($this->user_model->updateProfile($this->user_id,$data)){
      $response['status'] = true;
      $response['code'] = 200;
      $response['msg'] = 'Profile Updated Successfully ';
      return $this->response($response,$response['code']);
    } else {
      $response['code'] = 500;
      $response['msg'] = 'Some Error Occured . Could Not update Profile ';
      return $this->response($response,$response['code']);
    }

  }

}

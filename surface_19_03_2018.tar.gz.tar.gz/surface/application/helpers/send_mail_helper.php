<?php
function sendMail($message,$subject,$to)
{
    $config = Array(
  'protocol' => 'smtp',
  'smtp_host' => 'ssl://smtp.googlemail.com',
  'smtp_port' => 465,
  'smtp_user' => 'durgeshchandra.mishra@appinventiv.com', // change it to yours
  'smtp_pass' => 'app@@321', // change it to yours
  'mailtype' => 'html',
  'charset' => 'iso-8859-1',
  'wordwrap' => TRUE
);
$CI =& get_instance();
// load library
// $config['protocol'] = 'sendmail';
// $config['smtp_host'] = 'tls://mail.applaurels.com';
// $config['charset'] = 'utf-8';
// $config['mailtype'] = 'html';
$config['from'] = 'info@surface.com';
$config['from_name'] = 'Surface';
 $config['reply_to'] = 'norepl@surface.com';
 $config['reply_to_name'] = 'Surface';
// $config['mailpath'] ="/usr/sbin/sendmail";

        //$message = '';
      $CI->load->library('email',$config);
      $CI->email->set_newline("\r\n");
      $CI->email->from('info@surface.com'); // change it to yours
      $CI->email->to($to);// change it to yours
      $CI->email->subject($subject);
      $CI->email->message($message);
      if($CI->email->send())
     {
      return true;
     }
    //  else
    // {
    //  show_error($CI->email->print_debugger());
    // }
    return false;

}

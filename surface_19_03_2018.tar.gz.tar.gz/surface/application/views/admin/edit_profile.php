<?php
require 'header.php';
require 'left_bar.php';
require 'nav_bar.php';
 ?>
 <div class="right-panel">
             <div class="inner-right-panel">
               <?php echo form_open_multipart('/admin/profile/edit'); ?>
                 <!--breadcrumb wrap-->
                 <div class="breadcrumb-wrap">
                     <ol class="breadcrumb">
                         <li class="breadcrumb-item"><a href="javascript:void(0);">Dashboard</a></li>
                         <li class="breadcrumb-item"><a href="profile.html">Admin Profile</a></li>
                         <li class="breadcrumb-item active">Admin Edit Profile</li>
                     </ol>
                 </div>
                 <!--breadcrumb wrap close-->

                 <div class="section">
                     <div class="user-detail-panel">
                         <div class="row">
                             <div class="col-lg-3 col-sm-3">
                                 <!-- thumb wrapper -->
                                 <div class="image-view-wrapper img-view200p img-viewbdr-radius4p">
                                     <div class="profile-pic" style="background-image:url('<?php
                                      $profileImage = base_url()."uploads/".$_SESSION['user_data']['profile_image'];
                                     if(isset($_SESSION['user_data']['profile_image'])){
                                       echo $profileImage;
                                     } else{
                                        echo base_url()."public/images/user.svg";}
                                        ?>');">
                                         <a href="javascript:void(0);" class="upimage-btn">

                                             <input type="file" id="uploadPic" style="display:none;">
                                             <label class="camera" for="uploadPic"><i class="fa fa-camera" aria-hidden="true"></i></label>

                                         </a>
                                     </div>


                                     <div class="image-view img-view200" id="profilePic" style="background-image:url('<?php
                                      $profileImage = base_url()."uploads/".$_SESSION['user_data']['profile_image'];
                                     if(isset($_SESSION['user_data']['profile_image'])){
                                       echo $profileImage;
                                     } else{
                                        echo base_url()."public/images/user.svg";}
                                        ?>');">
                                         <a href="javascript:void(0);" class="upimage-btn">
                                             <input type="file" id="upload" style="display:none;" accept="image/*" name="admin_image">
                                         </a>
                                         <label class="camera" for="upload"><i class="fa fa-camera" aria-hidden="true"></i></label>
                                         <label id="image-error" class="alert-danger"><?php if (isset($error)) {
                                           echo $error;
                                         }
                                         if (isset($_SESSION['msg'])) {
                                           echo $_SESSION['msg'];
                                         }
                                         echo validation_errors();
                                         ?></label>
                                     </div>
                                 </div>
                                 <!-- //thumb wrapper -->
                                 <span class="loder-wrraper-single"></span>
                             </div>
                             <div class="col-lg-9 col-sm-9 col-xs-12">
                                 <div class="user-detail-panel">
                                     <div class="row">
                                         <div class="col-sm-4">
                                             <div class="form-group">
                                                 <label class="admin-label">Name</label>
                                                 <div class="input-holder">
                                                     <input type="text" maxlength="100" name="name" id="Admin_Name" value="<?php echo $_SESSION['user_data']['name'];?>">

                                                 </div>
                                             </div>
                                         </div>
                                         <div class="col-sm-4">
                                             <div class="form-group">
                                                 <label class="admin-label">Email ID</label>
                                                 <div class="input-holder">
                                                     <input type="text"  maxlength="100" name="email" value="<?php echo $_SESSION['user_data']['email'];?>" id="email">

                                                 </div>
                                             </div>
                                         </div>
                                         <div class="col-sm-4">
                                             <div class="form-group">
                                                 <label class="admin-label">Mobile Number</label>
                                                 <div class="input-holder">
                                                     <input type="text"  maxlength="100" name="mobile" value="<?php echo $_SESSION['user_data']['mobile'];?>" id="mobile">

                                                 </div>
                                             </div>
                                         </div>
                                     </div>
                                 </div>
                             </div>
                             <div class="clearfix">
                               <span class='error'> <?php echo validation_errors(); ?></span>
                             </div>
                             <div class="button-wrap text-center">
                                 <button type="button" onclick="window.location.href='profile.html'" class="commn-btn cancel">Cancel</button>
                                 <button type="submit" class="commn-btn save">Save</button>
                             </div>
                         </div>
                     </div>
                 </div>
               </form>
                 <!--close form view   -->
                 <!--Filter Section Close-->
             </div>
             <!--Table listing-->
         </div>
<?php require 'footer.php' ?>

<?php
require 'header.php';
require 'left_bar.php';
require 'nav_bar.php';
 ?>
 <div class="right-panel">
             <div class="inner-right-panel">

                 <!--breadcrumb wrap-->
                 <div class="breadcrumb-wrap">
                     <ol class="breadcrumb">
                         <li class="breadcrumb-item"><a href="javascript:void(0);">Dashboard</a></li>
                         <li class="breadcrumb-item active">Change Password</li>
                     </ol>
                 </div>
                 <!--breadcrumb wrap close-->
                 <!-- form -->
                 <?php echo form_open('/admin/profile/change_password'); ?>
                 <div class="section clearfix">
                     <div class="user-detail-panel">
                         <div class="row">
                             <div class="col-sm-4 col-xs-12">
                                 <div class="form-group">
                                     <label class="admin-label">Old Password<span class="req_str">*</span></label>
                                     <div class="input-holder">
                                         <input type="password" maxlength="16" class="form-control material-control" name="oldpassword" value="">

                                         <!-- <span class="error_wrap"></span> -->
                                     </div>
                                 </div>
                             </div>
                             <div class="col-sm-4 col-xs-12">
                                 <div class="form-group">
                                     <label class="admin-label">New Password <span class="req_str">*</span></label>
                                     <div class="input-holder">
                                         <input type="password" maxlength="16" class="form-control material-control" name="password" value="" id="password">

                                         <!-- <span class="error_wrap"></span> -->
                                     </div>
                                 </div>
                             </div>
                             <div class="col-sm-4 col-xs-12">
                                 <div class="form-group">
                                     <label class="admin-label">Confirm Password <span class="req_str">*</span></label>
                                     <div class="input-holder">
                                         <input type="password" maxlength="16" class="form-control material-control" name="confirm_password" value="">

                                         <!-- <span class="error_wrap"></span> -->
                                     </div>
                                 </div>
                             </div>
                             <div class="clearfix" align='center'><span class="error"><?php echo validation_errors(); if (isset($_SESSION['msg'])) {
                               echo $_SESSION['msg'];
                             } ?></span></div>

                             <div class="col-xs-12">
                                 <div class="button-wrap">
                                     <button type="button" onclick="window.location.href='<?php echo site_url('admin/profile') ?>'" class="commn-btn cancel">Cancel</button>
                                     <button type="submit" class="commn-btn save">Save</button>
                                 </div>
                             </div>

                         </div>
                     </div>
                 </div>
               </form>
                 <!-- form -->
             </div>
         </div>
<?php require 'footer.php' ?>

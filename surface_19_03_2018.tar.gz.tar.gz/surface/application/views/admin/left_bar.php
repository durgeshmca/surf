<body class="">
    <div class="in-data-wrap">
        <!--left panel-->
        <aside class="sidebar-wrapper">
            <div class="closeSidebar768">x</div>
            <div class="sidebar-menu">
                <div class="user-short-detail">
                    <div class="image-view-wrapper img-view80p img-viewbdr-radius">
                        <div id="lefft-logo" class="image-view img-view80" style="background:url('<?php
                         $profileImage = base_url()."uploads/".$_SESSION['user_data']['profile_image'];
                        if(isset($_SESSION['user_data']['profile_image'])){
                          echo $profileImage;
                        } else{
                           echo base_url()."public/images/user.svg";}
                           ?>
                        ')"></div>
                    </div>
                    <span class="user-name"><?php echo $_SESSION['user_data']['name']; ?></span>
                </div>
                <div class="left-menu side-panel">
                    <ul>
                        <li>
                            <a href="javascript:void(0);" class="active">
                                <span class="left_icon dash_1"></span>

                                <span class="nav-txt">Users</span>
                            </a>
                        </li>
                        <li>
                            <a href="javascript:void(0);" data-toggle="modal" data-target="#myModal-message" >
                                <span class="left_icon dash_3"> </span>

                                <span class="nav-txt">Posts</span>
                            </a>
                        </li>
                        <li>
                            <a href="content.html">
                                <span class="left_icon dash_4"></span>

                                <span class="nav-txt">Content</span>
                            </a>
                        </li>
                        <!-- <li>
                            <a href="manage_version.html">
                                <span class="left_icon dash_5"></span>

                                <span class="nav-txt">Manage Version</span>
                            </a>
                        </li> -->
                        <li>
                            <a href="javascript:void(0);" data-toggle="modal" data-target="#myModal-message" >
                                <span class="left_icon dash_6"></span>
                                <!-- <img src="<?php echo base_url();?>public/images/first-aid-kit.svg" alt="Emergency"> -->
                                <span class="nav-txt">Notifications</span>
                            </a>
                        </li>
                        <li class="drop_down_action">
                            <a href="javascript:void(0)">
                                <span class="left_icon dash_7"></span>
                                <!-- <img src="<?php echo base_url();?>public/images/notification.svg" alt="Notification"> -->
                                <span class="nav-txt">Reported Content</span><span class="inner_drop_menu"></span>
                            </a>

                            <ul class="drop_down_menu">
                                <li>
                                    <a href="javascript:void(0);" data-toggle="modal" data-target="#myModal-message" >
                                        <span class="left_icon dash_1"></span>
                                        <span class="nav-txt">User</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="javascript:void(0);" data-toggle="modal" data-target="#myModal-message" >
                                        <span class="left_icon dash_3"> </span>
                                        <span class="nav-txt">Posts</span>
                                    </a>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </div>
        </aside>
        <!--left panel-->

<?php
require 'header.php';
require 'left_bar.php';
require 'nav_bar.php';
 ?>
 <div class="right-panel">
             <div class="inner-right-panel">

                 <!--breadcrumb wrap-->
                 <div class="breadcrumb-wrap">
                     <ol class="breadcrumb">
                         <li class="breadcrumb-item"><a href="<?php echo site_url('admin/users');?>">Users</a></li>
                         <li class="breadcrumb-item">Users Detail</li>
                     </ol>
                 </div>
                 <!-- form panel -->
                 <div class="form-item-wrap">
                     <div class="form-item-title clearfix">
                         <h3 class="title">User Detail</h3>
                     </div>
                     <!-- title and form upper action end-->
                     <div class="form-ele-wrapper clearfix">
                         <div class="row">
                             <div class="col-lg-4 col-sm-4 col-xs-12">
                                 <div class="form-profile-pic-wrapper">
                                     <div class="profile-pic" style="background-image:url('<?php echo base_url('/public');?>/images/user-placeholder.png');">

                                     </div>
                                 </div>
                             </div>
                             <!--form ele wrapper-->
                             <div class="col-lg-8 col-sm-8 col-xs-12">
                                 <div class="user-detail-panel">
                                     <div class="col-lg-6 col-sm-6 col-xs-12">
                                         <div class="form-group">
                                             <label>Name</label>
                                             <div class="input-holder">
                                                 <span class="text-detail"><?php echo $profile['name'] ?></span>
                                             </div>
                                         </div>
                                     </div>
                                     <div class="col-lg-6 col-sm-6 col-xs-12">
                                         <div class="form-group">
                                             <label>Email ID</label>
                                             <div class="input-holder">
                                                 <span class="text-detail"><?php echo $profile['email'] ?></span>
                                             </div>
                                         </div>
                                     </div>
                                     <div class="col-lg-6 col-sm-6 col-xs-12">
                                         <div class="form-group">
                                             <label>Username</label>
                                             <div class="input-holder">
                                                 <span class="text-detail"><?php echo $profile['user_name'] ?></span>
                                             </div>
                                         </div>
                                     </div>
                                     <div class="col-lg-6 col-sm-6 col-xs-12">
                                         <div class="form-group">
                                             <label>Lives in</label>
                                             <div class="input-holder">
                                                 <span class="text-detail"><?php echo $profile['location'] ?></span>
                                             </div>
                                         </div>
                                     </div>
                                     <div class="col-lg-6 col-sm-6 col-xs-12">
                                         <div class="form-group">
                                             <label>Registered on</label>
                                             <div class="input-holder">
                                                 <span class="text-detail"><?php echo $profile['created_at'] ?></span>
                                             </div>
                                         </div>
                                     </div>
                                     <div class="col-lg-6 col-sm-6 col-xs-12">
                                         <div class="form-group">
                                             <label>Status</label>
                                             <div class="input-holder">
                                                 <span class="text-detail"><?php if ($profile['status']) {
                                                   $changeBlockStatusTo = 0;
                                                   $blockButtonMsg = "Block User";
                                                   echo "Active";
                                                 } else {
                                                   $changeBlockStatusTo = 1;
                                                   $blockButtonMsg = "Unblock User";
                                                   echo "Inactive";
                                                 }?></span>
                                             </div>
                                         </div>
                                     </div>
                                 </div>
                             </div>
                             <div class="col-lg-12 col-sm-12 col-xs-12">
                                 <div class="button-wrap">
                                     <button type="submit" class="commn-btn save"  onclick="openBlock('<?php echo $profile['user_id'] ?>','<?php echo $changeBlockStatusTo ?>');" title="Block"><?php echo $blockButtonMsg; ?></button>
                                 </div>
                             </div>
                         </div>
                         <!--form ele wrapper end-->
                     </div>
                     <!--form element wrapper end-->
                 </div>
                 <div class="form-item-wrap">
                     <div class="form-item-title clearfix">
                         <h3 class="title">Friends</h3>
                     </div>
                     <!-- title and form upper action end-->
                     <div class="form-ele-wrapper clearfix pd_form">
                         <div class="row">
                             <!--form view details wrapper-->
                             <div class="col-lg-12 col-sm-12">
                                 <div class="col-lg-4 col-sm-4 col-xs-12">
                                     <div class="friend_list_panel clearfix">
                                         <figure class="friend_img"><img src="<?php echo base_url('/public');?>/images/user-placeholder.png"></figure>
                                         <div class="friend_name">
                                             <h2>Alber to</h2>
                                         </div>
                                     </div>
                                 </div>
                                 <div class="col-lg-4 col-sm-4 col-xs-12">
                                     <div class="friend_list_panel clearfix">
                                         <figure class="friend_img"><img src="<?php echo base_url('/public');?>/images/user-placeholder.png"></figure>
                                         <div class="friend_name">
                                             <h2>Alber to</h2>
                                         </div>
                                     </div>
                                 </div>
                                 <div class="col-lg-4 col-sm-4 col-xs-12">
                                     <div class="friend_list_panel clearfix">
                                         <figure class="friend_img"><img src="<?php echo base_url('/public');?>/images/user-placeholder.png"></figure>
                                         <div class="friend_name">
                                             <h2>Alber to</h2>
                                         </div>
                                     </div>
                                 </div>
                             </div>
                             <div class="col-lg-12 col-sm-12">
                                 <div class="col-lg-4 col-sm-4 col-xs-12">
                                     <div class="friend_list_panel clearfix">
                                         <figure class="friend_img"><img src="<?php echo base_url('/public');?>/images/user-placeholder.png"></figure>
                                         <div class="friend_name">
                                             <h2>Alber to</h2>
                                         </div>
                                     </div>
                                 </div>


                                 <div class="col-lg-4 col-sm-4 col-xs-12">
                                     <div class="friend_list_panel clearfix">
                                         <figure class="friend_img"><img src="<?php echo base_url('/public');?>/images/user-placeholder.png"></figure>
                                         <div class="friend_name">
                                             <h2>Alber to</h2>
                                         </div>
                                     </div>
                                 </div>
                                 <div class="col-lg-4 col-sm-4 col-xs-12">
                                     <div class="friend_list_panel clearfix">
                                         <figure class="friend_img"><img src="<?php echo base_url('/public');?>/images/user-placeholder.png"></figure>
                                         <div class="friend_name">
                                             <h2>Alber to</h2>
                                         </div>
                                     </div>
                                 </div>
                             </div>
                             <div class="col-lg-12 col-sm-12">
                                 <div class="col-lg-4 col-sm-4 col-xs-12">
                                     <div class="friend_list_panel clearfix">
                                         <figure class="friend_img"><img src="<?php echo base_url('/public');?>/images/user-placeholder.png"></figure>
                                         <div class="friend_name">
                                             <h2>Alber to</h2>
                                         </div>
                                     </div>
                                 </div>
                                 <div class="col-lg-4 col-sm-4 col-xs-12">
                                     <div class="friend_list_panel clearfix">
                                         <figure class="friend_img"><img src="<?php echo base_url('/public');?>/images/user-placeholder.png"></figure>
                                         <div class="friend_name">
                                             <h2>Alber to</h2>
                                         </div>
                                     </div>
                                 </div>
                             </div>
                             <div class="col-lg-12 col-sm-12">
                                 <div class="all_view_panel">
                                     <a href="javascript:void(0);">See More..</a>
                                 </div>
                             </div>
                             <!--form view details wrapper end-->
                         </div>
                     </div>
                     <!--form element wrapper end-->
                 </div>
                 <div class="form-item-wrap">
                     <div class="form-item-title clearfix">
                         <h3 class="title">Posts</h3>
                     </div>
                     <!-- title and form upper action end-->
                     <div class="form-ele-wrapper clearfix pd_form">
                         <div class="row">
                             <!--form view details wrapper-->
                             <div class="col-lg-12 col-sm-12">
                               <?php if (isset($posts)) {
                                 foreach ($posts['data'] as $key => $value) {?>

                                 <div class="col-lg-6 col-sm-6">
                                     <div class="friend_list_panel clearfix">
                                         <figure class="friend_img"><img src="<?php echo base_url('/public');?>/images/user-placeholder.png"></figure>
                                         <div class="friend_name">
                                             <div class="comm_post_det">
                                                 <span>Views:</span>
                                                 <a href="user_view_panel.html"><?php echo $value['views_count'] ?></a>
                                             </div>
                                             <div class="comm_post_det">
                                                 <span>Comments:</span>
                                                 <a href="user_view_panel.html"><?php echo $value['comments_count'] ?></a>
                                             </div>
                                             <div class="comm_post_det">
                                                 <span>Shares:</span><span><?php echo $value['shares_count'] ?></span>
                                             </div>
                                             <div class="comm_post_det">
                                                 <span>Tags:</span>
                                                 <a href="user_view_panel.html"><?php echo substr_count($value['tags'], ','); ?></a>
                                             </div>
                                             <div class="comm_post_det">
                                                 <span>Description</span>
                                                 <span class="dec_wrap"><?php echo $value['description'] ?></span>
                                             </div>
                                             <span class="time_show"><?php
                                             $dteStart = new DateTime($value['created_at']);
                                             echo ago($dteStart); ?></span>

                                             <a href="javascript:void(0);" class="delete-modal-data-action" data-toggle="modal" data-target="#myModal-trash" title="Delete">
                                                 <i class="fa fa-trash" title="Delete" onclick=""></i>
                                             </a>
                                             <a href="user_post_detail.html" class="view_detail"><i class="fa fa-angle-double-right"></i></a>
                                         </div>
                                     </div>
                                 </div>
                               <?php } } ?>

                             </div>

                                 <div class="all_view_panel">
                                     <a href="javascript:void(0);">See More..</a>
                                 </div>
                             </div>
                             <!--form view details wrapper end-->
                         </div>
                     </div>
                     <!--form element wrapper end-->
                 </div>
                 <!-- form panel close -->

             </div>
             <!--main wrapper close-->

<?php require 'footer.php' ?>

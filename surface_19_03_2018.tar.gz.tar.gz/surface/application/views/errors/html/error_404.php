<!doctype html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="author" content="">
    <title>SurfaceApp</title>

    <style>
        header {
            background: rgb(42, 64, 114);
            width: 100%;
            height: 62px;
            padding: 5px 25px;
            font-family: 'Open Sans', sans-serif;
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            -ms-flex-wrap: wrap;
            flex-wrap: wrap;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            padding: 8px 16px 8px 70px;
        }

        .inner-header h1 {
            color: #fff;
            text-align: center;
            font-size: 25px;
            line-height: 1.8;
        }

        .component-error-wrapper {
            height: 100%;
            display: block;
        }

        .error_wrapper {
            position: absolute;
            left: 50%;
            top: 50%;
            transform: translate(-50%, -50%);
        }

        .err0r_page_wrap {
            text-align: center;
            padding: 36px 0;
        }

        .err0r_page_wrap h1 {
            font-size: 32px;
            color: #464040;
            padding-bottom: 6px;
        }

        .err0r_page_wrap h2 {
            font-size: 32px;
            color: #464040;
        }

        .error_wrapper p {
            font-size: 15px;
            padding-bottom: 4px;
            text-align: center;
        }

        a {
            color: rgb(42, 64, 114);
            text-decoration: none;
        }

        a:hover {
            color: rgb(42, 64, 114);
        }

        .data-wrap {
            min-height: 100%;
            padding: 0;
            width: 100%;
            overflow-x: hidden;
            position: absolute;
            top: 0;
            bottom: 0;
            left: 0;
            right: 0;
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -ms-flex-direction: column;
            flex-direction: column;
        }

        .clearfix {
            display: block;
        }

        .clearfix:before,
        .clearfix:after {
            content: " ";
            display: table;
        }

        .footer-wrap {
            padding: 12px 36px;
            text-align: center;
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            background: rgb(42, 64, 114);
            color: #fff;
            font-size: 14px;
        }
    </style>
</head>

<body>

    <!--Admin Data wrap-->
    <div class="data-wrap">
        <!--header-->
        <header class="clearfix">
            <div class="inner-header clearfix">
                <h1>404 Error !</h1>
            </div>
        </header>
        <!--header close-->
        <!-- component wrapper -->
        <div class="component-error-wrapper clearfix">
            <div class="error_wrapper">
                <div class="err0r_page_wrap">
                    <h1>404</h1>
                    <h2>Error ! <span>Page Under Development</span></h2>
                </div>
                <p>For Some Reason The Page You Requested is under development</p>
                <p><a href="javascript:void(0);">Go Home &raquo;</a></p>

            </div>
        </div>
        <!--component viewer end-->
        <div class="footer-wrap">
            <footer class="clearfix">
                &copy;2017-2018 Surface App All Rights Reserved
            </footer>
        </div>
    </div>
    <!--Admin Data wrap-->
    <!-- Java Script -->
</body>

</html>

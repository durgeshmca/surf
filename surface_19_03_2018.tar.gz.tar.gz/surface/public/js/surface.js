$('document').ready(function(){

    //
    // $('.cout').click(function(){
    //   var x = $(this).attr('data-ci-pagination-page');
    //   alert(x);
    //    //alert($(this).hash();
    // });


});

function openPage(id) {

  //alert(id);
  id = parseInt(id);
  load(id);
}
function openBlock(id,bstatus) {
  //alert(baseUrl);
  $("#blocklink").attr('href',baseUrl +'/admin/users/block/'+id+'/'+bstatus);
  $("#myModal-block").modal('show');

}
/********* load page****************/

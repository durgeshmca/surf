<?php
defined('BASEPATH') OR exit('No direct script access allowed');
//require_once APPPATH . 'libraries/REST_Controller.php';
class Authenticate
{
  protected $CI;
  protected $config;
  public function __construct()
  {
      //parent::__construct();
      $this->CI = &get_instance();
      $this->CI->load->database();
  }
  public function auth_check()
  {

  	if (isset($_SERVER['HTTP_ACCESS_TOKEN']) && !empty($_SERVER['HTTP_ACCESS_TOKEN'])) {
  		//echo 'Token:'.$_SERVER['HTTP_ACCESS_TOKEN'];
  		//get user_id based on data
  		$user_id = false;
  		$token = $_SERVER['HTTP_ACCESS_TOKEN'];
  		$this->CI->load->model('token_model');
  		$userId = $this->CI->token_model->check_token($token);
      //var_dump($userId);die;
  		if (is_array($userId) && !empty($userId['user_id'])) {
  		  $user_id = $userId['user_id'];
  			return $user_id;
  		}

  	}
    $response['status']=false;
  	$response['msg']= 'Unauthorized Access';
  	$response['code'] = 401;
    $jsonData = json_encode($response);
    http_response_code(401);
    header('Content-Type: application/json');
    echo json_encode($response);
    die;
  }

}

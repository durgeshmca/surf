<?php
$title = "Surface App";
//$file = $this->file;
$file = 'Surcae App';
//$description = $this->desc;
$description = 'Surface App';
//$token = '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<META NAME="MSSmartTagsPreventParsing" CONTENT="True">
<META HTTP-EQUIV="Expires" CONTENT="0">
<META HTTP-EQUIV="Pragma" CONTENT="No-Cache">
<META HTTP-EQUIV="Cache-Control" CONTENT="No-Cache,Must-Revalidate,No-Store">
<meta property="og:locale" content="en_US" />
<meta property="og:type" content="article" />
<meta property="og:title" content="<?php echo trim($title); ?>" />
<meta property="og:description" content="<?php echo trim($description); ?>" />
<meta property="og:image" content="<?php echo $file; ?>" />
<meta property="og:site_name" content="Gospic Application" />
</head>

<script src='//code.jquery.com/jquery-1.11.2.min.js'></script>
<script src='//mobileesp.googlecode.com/svn/JavaScript/mdetect.js'></script>
<script type="text/javascript">
(function() {
		var token = "<?php echo $token;?>";
    var ua = navigator.userAgent.toLowerCase();
            var isAndroid = ua.indexOf("android") > -1; //&& ua.indexOf("mobile");
            var isIphone = ua.indexOf("iphone") > -1;
             var url = window.location.href;

            if (isAndroid) {


			var url = "surface://details?id="+token;
			var appURL = 'https://play.google.com/store/apps/details?id='+token;

                window.location = url;
                var now = new Date().valueOf();
                setTimeout(function () {
                    if ((new Date().valueOf() - now) > 1500)
                        return;
                    window.location = appURL;
                }, 5000);





            } else if (isIphone) {

              		window.location.href = 'https://itunes.apple.com/us/app/surface/'+token;
                        window.location.replace("surface://?token_"+token);
                this.timer = setTimeout(this.openWebApp, 5000);
            } else {

              window.location.href = 'http://surface.appinventive.com?token='+token;

            }
        })();
</script>

</html>

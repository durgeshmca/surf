<?php
require 'header.php';
require 'left_bar.php';
require 'nav_bar.php';
 ?>
<div class="right-panel">
            <div class="inner-right-panel">
                <!--breadcrumb wrap-->
                <div class="breadcrumb-wrap">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0);">Setting</a></li>
                        <li class="breadcrumb-item active">Admin Profile</li>
                    </ol>
                </div>
                <!--breadcrumb wrap close-->

                <!--Filter Section -->
                <div class="section">
                    <div class="user-detail-panel">
                        <div class="row">
                            <div class="col-lg-3 col-sm-3">

                                <div class="profile-pic image-view img-view200" style="background-image:url('<?php echo base_url()?>/public/images/user.svg');">
                                </div>

                                <span class="loder-wrraper-single"></span>
                            </div>
                            <div class="col-lg-9 col-sm-9 col-xs-12">
                                <div class="user-detail-panel">
                                    <div class="row">
                                        <div class="col-lg-2 col-sm-4 col-xs-12">
                                            <div class="form-group">
                                                <label class="admin-label">Name</label>
                                                <div class="input-holder">
                                                    <span class="text-detail"><?php echo $_SESSION['user_data']['name']; ?></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-sm-4 col-xs-12">
                                            <div class="form-group">
                                                <label class="admin-label">Email ID</label>
                                                <div class="input-holder">
                                                    <span class="text-detail"><?php echo $_SESSION['user_data']['email']; ?></span>
                                                </div>

                                            </div>
                                        </div>
                                        <div class="col-lg-4 col-sm-4 col-xs-12">
                                            <div class="form-group">
                                                <label class="admin-label">Mobile Number</label>
                                                <div class="input-holder">
                                                    <span class="text-detail"><?php echo $_SESSION['user_data']['mobile']; ?></span>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-12">
                                <div class="button-wrap">

                                    <a href="<?php echo site_url('admin/profile/change_password') ?>" class="profile_btn"><button type="button" name="changepassword" class="commn-btn save">Change Password</button></a>
                                    <a href="<?php echo site_url('admin/profile/edit') ?>" class="profile_btn"><button type="button" name="editprofile" class="commn-btn save">Edit Profile</button></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
<?php require 'footer.php' ?>

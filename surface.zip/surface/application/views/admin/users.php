<?php
require 'header.php';
require 'left_bar.php';
require 'nav_bar.php';
 ?>
<div class="right-panel">
            <div class="inner-right-panel">

                <!--breadcrumb wrap-->
                <div class="breadcrumb-wrap">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item">Users</li>
                    </ol>
                </div>

                <!--Filter Section -->
                <div class="section filter-section clearfix">
                    <div class="row">
                        <div class="col-lg-2 col-sm-3">
                            <div class="display col-sm-space">
                                <select class="selectpicker" id = "selectpicker" onchange="search(this.'1');">
                                <option value="2">10</option>
                                <option  value="20">20</option>
                                <option value="50">50</option>
                                <option value="100">100</option>
                                </select>
                            </div>
                        </div>

                        <div class="col-lg-6 col-sm-6">
                            <div class="srch-wrap fawe-icon-position col-sm-space">
                                <span class="fawe-icon fawe-icon-position-left search-ico"><i class="fa fa-search"></i></span>
                                <span class="fawe-icon fawe-icon-position-right close-ico"><i class="fa fa-times-circle"></i></span>
                                <!-- <button class="srch search-icon" style="cursor:default"></button>
                                         <a href="javascript:void(0)"> <span class="srch-close-icon searchCloseBtn"></span></a> -->
                                <input type="text" maxlength="15" value="" class="search-box searchlike" placeholder="Search by Name , Username or Email" id="searchuser" name="search" onchange="load();">
                            </div>
                        </div>

                        <div class="col-lg-4 col-sm-3">
                            <div class="circle-btn-wrap col-sm-space">
                                <a href="javascript:void(0)" id="filter-side-wrapper" class="tooltip-p">
                                    <div class="circle-btn animate-btn" title="Filter">
                                        <i class="fa fa-filter" aria-hidden="true"></i>
                                    </div>

                                </a>
                                <a href="javascript:void(0);" class="circle-btn">
                                    <img src="<?php echo base_url();?>public/images/save.svg">
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <!--Filter Section Close-->

                <!--Filter Wrapper-->
                <div class="filter-wrap ">
                    <div class="filter_hd clearfix">
                        <div class="pull-left">
                            <h2 class="fltr-heading">Filter</h2>
                        </div>
                        <div class="pull-right">
                            <span class="close flt_cl" data-dismiss="modal">X</span>
                        </div>
                    </div>
                    <div class="inner-filter-wrap">
                        <div class="fltr-field-wrap">
                            <label class="admin-label">Status</label>
                            <div class="commn-select-wrap">
                                <select class="selectpicker filter status" name="status">
                                            <option value="">Active</option>
                                            <option>Active</option>
                                            <option>Inactive</option>
                                        </select>

                            </div>
                        </div>
                        <div class="fltr-field-wrap">
                            <label class="admin-label">Date</label>
                            <div class="inputfield-wrap calendersec">
                                <input type="text" name="startDate" value="" class="startDate" id="startDate" placeholder="From">
                                <span class="cal_bg"></span>
                            </div>
                            <div class="inputfield-wrap calendersec">
                                <input type="text" name="endDate" data-provide="datepicker" value="" class="endDate" id="endDate" placeholder="To">
                                <span class="cal_bg"></span>
                            </div>
                        </div>

                        <div class="fltr-field-wrap">
                            <label class="admin-label">Lives In</label>
                            <div class="commn-select-wrap">
                                <select class="selectpicker filter status">
                                    <option value="">Select</option>
                                    <option>0</option>
                                    <option>1</option>
                                </select>

                            </div>
                        </div>
                        <div class="fltr-field-wrap">
                            <label class="admin-label">Total Posts</label>
                            <div class="commn-select-wrap">
                                <select class="selectpicker filter status">
                                        <option value="">Select Status</option>
                                        <option>0</option>
                                        <option>1</option>
                                    </select>

                            </div>
                        </div>


                        <div class="button-wrap">
                            <button type="reset" class="commn-btn cancel" id="resetbutton">Reset</button>
                            <input type="submit" class="commn-btn save" id="filterbutton" name="filter" value="Apply">
                        </div>

                    </div>
                </div>
                <!--Filter Wrapper Close-->
                <div class="section">



                    <div class="table-responsive table-wrapper">
                        <table cellspacing="0" id="example" class="table-custom sortable">
                            <thead>

                                <tr>
                                    <th>S.No</th>
                                    <th>
                                        Name
                                    </th>
                                    <th>Email Id</th>
                                    <th>Username</th>
                                    <th>Lives in</th>
                                    <th>Registered On</th>
                                    <th>Total Posts</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody id="tbody">
                              <?php
                              $total_users = $users['total'];
                              unset($users['total']);
                              $i=1;
                              foreach ($users as $user) { ?>


                                <tr>

                                    <td><?php echo $i++; ?></td>
                                    <td><a href="javascript:void(0);"><?php echo $user['name']; ?></a></td>
                                    <td><?php echo $user['email']; ?></td>
                                    <td><?php echo $user['user_name']; ?></td>
                                    <td>Lorem Ipsun</td>
                                    <td><?php echo $user['created_at']; ?></td>

                                    <td>
                                        <?php echo $user['posts_count']; ?>
                                    </td>
                                    <td><?php if ($user['status']) {
                                      $changeBlockStatusTo = 0;
                                      $blockButtonMsg = "Block User";
                                      $icon = 'fa fa-ban';
                                      echo "Active";
                                    } else {
                                      $changeBlockStatusTo = 1;
                                      $blockButtonMsg = "Unblock User";
                                      $icon = 'fa fa-unlock';
                                      echo "Inactive";
                                    }?></a>
                                    </td>
                                    <td class=" table-action">
                                        <a href="<?php echo site_url('/admin/users/get_user/').$user['user_id']; ?>" class="f-eye"><i class="fa fa-eye" title="View"></i></a>
                                        <a href="javascript:void(0);" class="f-trash" onclick="openBlock('<?php echo $user['user_id'] ?>','<?php echo $changeBlockStatusTo ?>');"><i class="<?php echo $icon; ?>"></i></a>

                                    </td>
                                </tr>
                            <?php } ?>?>

                            </tbody>
                        </table>
                    </div>
                    <div class="pagination_wrap clearfix" id="pagging">
                      <?php echo $pagging; ?>

                      <!--  <ul>
                            <li><a href="javascript:void(0);" class="page_cout active">1</a></li>
                            <li>
                                <a href="javascript:void(0);" class="page_cout">2</a>
                            </li>
                            <li>
                                <a href="javascript:void(0);" class="page_cout">3</a>
                            </li>
                            <li>
                                <a href="javascript:void(0);" class="page_cout">Next</a>
                            </li>
                        </ul> -->

                    </div>
                    <div class="x" id='mypagging'>

                    </div>
                </div>
            </div>
            <!--main wrapper close-->
        </div>
<script>
function load(page_no=1) {
  var pplimit = $("#selectpicker option:selected").val();
  var searchdata = $("#searchuser").val();
  var curl = "<?php echo site_url('admin/users/list_user/') ?>"+pplimit+"/"+page_no;
  $.ajax({
    url : curl,
    type : "post",
    data : 'search='+searchdata,
    xhrFields: { withCredentials:true },
    success:function(result){
      $("#pagging").html(result);
      //var data = $.parseJSON(result);
      var tbl ='<tr>';
      $newData = result.data;
      if(result.total > 0){
      $.each($newData, function(i, item) {
      tbl +='<td>'+ parseInt(i+1) +'</td>';
      tbl +='<td><a href="javascript:void(0);">'+ item.name +'</td>';
      tbl +='<td>'+item.email+'</td>';
      tbl +='<td>'+item.user_name+'</td>';
      tbl +='<td>'+item.email+'</td>';
      tbl +='<td>'+item.created_at+'</td>';
      tbl +='<td>'+item.posts_count+'</td>';
      if(item.status) {
        var changeBlockStatusTo = 0;
        var blockButtonMsg = "Block User";
        var icon = 'fa fa-ban';
        var stats ='Active';
        } else {
          var changeBlockStatusTo = 1;
          var blockButtonMsg = "Unblock User";
           var icon = 'fa fa-unlock';
          var stats ='Inctive';
        }


      tbl +='<td>'+stats+'</td>';
      tbl +='<td class=" table-action"> <a href="<?php echo site_url('/admin/users/get_user/'); ?>'+item.user_id+'" class="f-eye"><i class="fa fa-eye" title="View"></i></a><a href="javascript:void(0);" class="f-trash" onclick="openBlock(\''+item.user_id+'\',\''+changeBlockStatusTo+'\');"><i class="'+icon+'"></i></a></td></tr>';
      });
    }else {
      tbl +='<td colspan="9">No result Found</td></tr>';
    }

      $("#tbody").html(tbl);
      $("#pagging").html(' ');
      $("#pagging").append(result.pagging);
    }




  });
}
$("#selectpicker").change(function(){
  load();

});
$('#page_cout').click( function(){
  alert('Page Clicked');
});
</script>
<?php require 'footer.php' ?>

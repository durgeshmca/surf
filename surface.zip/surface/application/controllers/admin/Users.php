<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Users extends CI_Controller {
  protected $user_data ;
  public function __construct()
  {

    parent::__construct();
     $this->load->model('admin_model');
     $this->load->model('post_model');
     $this->load->library('auth_admin');
     $this->load->helper(['form','security','days_count']);
     $this->load->library('pagination');
     $this->user_data = $this->auth_admin->check_auth(); //checks and set user data
  }
  public function index($page = 1)
  {
    $page = xss_clean($page);
    $page = (int) $page;
    if ($page <=0 ) {
      $page = 1;
    }
    $limit = 2;
    $offset = ($page -1) * $limit;
    $users = $this->admin_model->listUsers($offset,$limit);
    $this->user_data['users'] = $users['data'];
    $this->user_data['users']['total'] = $users['total'];
    //pagging
    $config['base_url'] = site_url('/admin/users/index');
    $config['total_rows'] = $users['total'];
    $config['per_page'] = $limit ;
    $config['full_tag_open'] = "<ul>" ;
    $config['full_tag_close'] = "</ul>" ;
    $config['attributes'] = array('class' => 'page_cout');
    $config['current_tag_open'] = "<li class='page_cout active'>" ;
    $config['current_tag_close'] = "</li>" ;
    $this->pagination->initialize($config);
    $this->user_data['pagging'] = $this->pagination->create_links();

    $this->load->view('admin/users',$this->user_data);
  }
  /*******
  Method to view user's list from ajax
  **********/
  public function list_user($ppLimit = 10,$page = 1) //per page limit
  {
    $ppLimit = (int) $ppLimit;
    $ppLimit = ($ppLimit <= 0)? 10 : $ppLimit ;
    $page = (int) $page;
    $page = ($page <= 0)? 1 : $page ;
    if ($this->input->method() == 'post') {
      $search = $this->input->post('search');
      $search = xss_clean($search);
      $offset = ($page -1) * $ppLimit;
      $users = $this->admin_model->listUsers($offset,$ppLimit,$search);
      $config['base_url'] = 'javascript:void(0);';
      $config['total_rows'] = $users['total'];
      $config['per_page'] = $ppLimit ;
      $config['full_tag_open'] = '<ul>';
      $config['full_tag_close'] = '</ul>';
      //$config['uri_segment']=3;
      //$config['use_page_numbers'] = TRUE;
      $config['attributes'] = array('class' => 'page_cout','onclick'=>'openPage();','data-id'=>'123');
      $config['current_tag_open'] = "<li class='page_cout active'>" ;
      $config['current_tag_close'] = "</li>" ;
      $this->pagination->initialize($config);
    //  $users['pagging'] = $this->pagination->create_links();
    $users['pagging'] =explode('javascript:void(0);/', $this->pagination->create_links());
    if (!empty($users['pagging'])) {
      # code...

    foreach ($users['pagging'] as $key => $value) {
      if (strpos($value,'openPage')!==FALSE) {
        $pageNo = (int) $value;
        $users['pagging'][$key]= str_replace("openPage()","openPage('$pageNo')",$value);
      }

    }
    $users['pagging'] = implode('javascript:void(0);/',$users['pagging']);
  }
      //print_r($users);
      header("Content-Type: application/json");
      echo json_encode($users);
    }
  }

  /*method to list user profile with 10 posts and 10 friend

  *****************************************************/
  public function get_user($id)
  {
    $id = (int) $id;
    if (!empty($id) && $id > 0) {
      $userData = $this->admin_model->getUserProfile($id);
    //  echo "<pre>";
    //  print_r($userData);
      $userPosts = $this->post_model->listPost($id,0);
      if (is_array($userPosts)) {
        $userData['posts']=$userPosts;
      }
    //  print_r($userPosts);
      $this->load->view('admin/user_details',$userData);
    }
  }

  /********
  Method to block and unblock users

  ***************/
  public function block($user_id,$status)
  {
    $user_id = (int) $user_id;
    $status = (int) $status;
    if (isset($status) && $status >=0 && !empty($user_id) && $user_id > 0) {
      if($this->admin_model->blockUser($user_id,$status)){

      }
      redirect('/admin/users/get_user/'.$user_id);
    }
  }
}

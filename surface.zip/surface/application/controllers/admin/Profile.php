<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Profile extends CI_Controller {


  public function __construct()
  {
    parent::__construct();
    $this->load->library(['auth_admin']);
    $this->load->library(['form_validation','session']);
    $this->load->helper(['form','security']);
    $this->load->model('admin_model');
    $this->auth_admin->check_auth();
  }
  public function index()
  {
    $this->load->view('admin/profile');
  }
  public function change_password()
  {
    if ($this->input->method() == 'post') {
      //print_r($this->input->post());
      $oldp = $this->input->post('oldpassword');
      $newp = $this->input->post('password');
      $cnewp = $this->input->post('confirm_password');

      $this->form_validation->set_rules('oldpassword', 'Old Password', 'required')
                            ->set_rules('password', 'New Password', 'required|min_length[5]|max_length[12]')
                            ->set_rules('confirm_password', 'Confirm Password', 'required|matches[password]');
      if ($this->form_validation->run() !== FALSE)
        {
          $checkOld = $this->admin_model->checkLogin($_SESSION['user_data']['email'],$oldp);
          if ($checkOld) {
            $this->admin_model->changeAdminPassword($_SESSION['user_data']['id'],$oldp,$newp);
            $this->session->set_flashdata('msg','Password changed Successfully.');
            redirect('/admin/profile');
          } else {
            $this->session->set_flashdata('msg','Old Password is wrong.');
          }
          redirect('/admin/profile/change_password');
        }
    }
    $this->load->view('admin/change_password');
  }
  public function edit()
  {
    $this->load->view('admin/edit_profile');
  }
}

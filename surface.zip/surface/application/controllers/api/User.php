<?php
require APPPATH . 'libraries/REST_Controller.php';
/****************
	This controller will handle requests of signup ,forget username and passwords it will also check whether an email,mobile and username already exists or not.


********************/

class User extends REST_Controller {


	public function __construct()
        {
                parent::__construct();
                $this->load->model('checkuser_model');
								$this->load->model('otp_model');
								$this->load->model('user_model');
                $this->load->helper(['url_helper']);
								$this->load->helper('encrypt_decrypt');
								$this->load->helper('token_helper');
								$this->load->helper('send_mail');
        }

	/*******

		method to check whether an email is already registered or not.
		It will recieve an email id and will  response with status true or false with message

	*********/
	public function check_get()
    {
        $response['status'] = false ;
        $email = $this->get('email');
        $userName = $this->get('username');
        $mobile	= $this->get('mobile');

        //$response = ['status'=>'true','email'=>$email,'username'=>$userName,'mobile'=>$mobile];
        //$this->response($response, REST_Controller::HTTP_OK);
        // If no parameter exists return 400 Bad Request

        if($email ===NULL && $userName === NULL && $mobile === NULL) {
					$response['code'] =400;
        	$this->response(NULL, REST_Controller::HTTP_BAD_REQUEST);

        }
        if(!empty($email)){
        	$data['email'] = $email;
        	$response['email'] = $email;
        }
        if(!empty($userName)){
        	$data['username'] = $userName;
        	$response['username'] = $userName;
        }
        if(!empty($mobile)){
        	$data['mobile'] = $mobile;
        	$response['mobile'] =  $mobile;
        }
        //check in db

        $exists_status = $this->checkuser_model->check($data);
        if ($exists_status) {
        	$response['status'] = true ;
        	$response['msg'] = "user already exists with this details";
        } else {
        	$response['msg'] = "user does not exists with this details";
        }
				$response['code'] = REST_Controller::HTTP_OK;
        $this->response($response,REST_Controller::HTTP_OK);

    }

    /*************************************

	Method to signup user.
	there are two type of signup
	1. From app's signup form and
	2. From Social media login/signup
	To separate them there is a field named created_from which will take values as
	facebook,twitter,....
	All details will be stored in our database.



    ************************************/

    public function signup_post()
    {
			//validate data recieved
			$response['status'] = false;
			$error = false;
			$email = $this->post('email');
			$userName = $this->post('username');
			$password = $this->post('password');
			$countryCode = $this ->post('country_code');
			$mobile = $this->post('mobile');
			$signupType = $this->post('signup_type');
			if (empty($email) || filter_var($email, FILTER_VALIDATE_EMAIL) === FALSE) {
				$response['msg'] = "Email is invalid";
				$error = true;
			}
			if (empty($userName) || !preg_match('/^[a-zA-Z]+[a-zA-Z0-9._]+$/', $userName)) {
				$response['msg'].= "User Name Invalid. ";
				$error = true;
			}
			if (empty($password)) {
				$response['msg'].= "Password Is Empty. ";
				$error = true;
			}
			if (empty($countryCode) ) {
				$response['msg'].= "Country Code is Empty. ";
				$error = true;
			}
			if (empty($mobile)) {
				$response['msg'].= "Mobile No.  is Empty. ";
				$error = true;
			}
			if (empty($signupType)) {
				$signupType = 'app';
			}
			//if there is an error return status as false with error msg
			if($error){
				$response['code'] =400;
				return $this->response($response,REST_Controller::HTTP_BAD_REQUEST);
			} else {
				$exists_status = $this->checkuser_model->check(array('email'=>$email,'username'=>$userName,'mobile'=>$mobile));
        if ($exists_status) {
        	$response['status'] = false ;
        	$response['msg'] = "user already exists with this details";
					$response['code'] =409;
					return $this->response($response,409);
        }
				//add user in db
				$data = array(
					'user_name' => $userName,
					'password' => md5($password),
					'email'=>$email,
					'country_code' => $countryCode,
					'mobile' => $mobile,
					'provider' => $signupType,
					'created_at' => date('Y-m-d H:i:s',time()),
					'updated_at' =>date('Y-m-d H:i:s',time())
				);
				if($this->db->insert('Users',$data)){
					//now make user login
					$data['type']='app';
					$data['password']= $password;
					$loginData = $this->makeLogin($data);
					//$data['user_id'] = $loginData['user_id'];
					$data['access_token'] = $loginData['access_token'];
					$response['status'] = true;
					$response['msg'] = "User created successfully";
					unset($data['password']);
					$response['data'] = $data;
					$response['code'] =200;
					$data['user_id'] = $loginData['user_id'];
					$this->sendOtpUser($data);
				} else {
					//echo $this->db->last_query();
					$response['msg'] = "Some error Occured.";
					$response['code'] =500;
				}
				$this->response($response,$response['code']);
			}
    }

		/***************
		Method to check if a user from social media have already in our database
		it will return true if a user is present and status of his profile using field profile_status and false if not present

		***********************/
		public function social_check_get()
		{
			$provider = $this->get('provider');
			$uid = $this->get('uid');
			$response['status']=false;
			if (empty($uid) || empty($provider)) {
				$response['msg'] = "provider and uid must be present";
				$response['code'] = 400;
				return $this->response(NULL,REST_Controller::HTTP_BAD_REQUEST);
			}
			$exists_status = $this->checkuser_model->check_social($provider,$uid);
			//var_dump($exists_status);die;

			if (!$exists_status) {
				//$response['status'] = false;
				$response['msg'] = "User Does Not Exists.";
				$response['code'] = 200;
				return $this->response($response,$response['code']);
			} else {
				$response['status'] = true ;
				if (empty($exists_status['username']) || empty($exists_status['email']) || empty($exists_status['mobile']) || empty($exists_status['country_code'])) {
					$response['profile_status']='2';//1 for complete 2 for incomplete
					$response['msg']='User Exists with incomplete profile';
					$response['data'] = $exists_status;
					$response['code']=200; //incomplete profile
				}
				$response['profile_status']='1';// 1: complete 2: incomplete
				$response['msg']='User Exists with complete profile';
				//now make user login user
				$loginData = $this->makelogin(['user_name' => $exists_status['user_name'],
					'email' => $exists_status['email'],
					'mobile' => $exists_status['mobile'],
					'provider'=>$provider,
					'provider_uid' => $uid,
					'type' => 'social'
				]);
				$response['data']['access_token'] = $loginData['access_token'];
				$response['code']=200;
			}

			return $this->response($response,$response['code']=200);

		}
 /* Method to signup or login user using social media
here we shall recieve provider and provider_uid , email,mobile and username
 */
 public function social_signup_post()
 {
 				//validate data recieved

 				$response['status'] = false;
 				$error = false;
 				$email = $this->post('email');
 				$userName = $this->post('username');
 				$password = $this->post('password');// password not required
 				$countryCode = $this ->post('country_code');
 				$mobile = $this->post('mobile');
 				$provider = $this->post('provider');
				$provider_uid = $this->post('uid');
 				if (empty($email) || filter_var($email, FILTER_VALIDATE_EMAIL) === FALSE) {
 					$response['msg'] = "Email is invalid";
 					$error = true;
 				}
 				if (empty($userName) || !preg_match('/^[a-zA-Z]+[a-zA-Z0-9._]+$/', $userName)) {
 					$response['msg'].= "User Name Invalid. ";
 					$error = true;
 				}
 				/*if (empty($password)) {
 					$response['msg'].= "Password Is Empty. ";
 					$error = true;
 				}*/
 				if (empty($countryCode) ) {
 					$response['msg'].= "Country Code is Empty. ";
 					$error = true;
 				}
 				if (empty($mobile)) {
 					$response['msg'].= "Mobile No.  is Empty. ";
 					$error = true;
 				}
 				if (empty($provider)) {
					$response['msg'].= "Provider is Empty. ";
 					$error = true;
 				}
				if (empty($provider_uid)) {
					$response['msg'].= "Provider unique id is Empty. ";
 					$error = true;
 				}
 				//if there is an error return status as false with error msg
 				if($error){
					$response['code']=400;
 					return $this->response($response,REST_Controller::HTTP_BAD_REQUEST);
 				} else {
 					$exists_status = $this->checkuser_model->check_social($provider,$provider_uid);
 	        if (is_array($exists_status) && $exists_status['user_id']) {
 	        	$response['status'] = false ;
 	        	$response['msg'] = "user already exists with this details";
						$response['data'] = $exists_status;
						$response['code']=409;
						return $this->response($response,409);
 	        }
 					//add user in db
 					$data = array(
 						'user_name' => $userName,
 						'password' => md5($password),
 						'email'=>$email,
 						'country_code' => $countryCode,
 						'mobile' => $mobile,
 						'provider' => $provider,
						'provider_uid' => $provider_uid,
 						'created_at' => date('Y-m-d H:i:s',time()),
 						'updated_at' =>date('Y-m-d H:i:s',time())
 					);
 					if($this->db->insert('Users',$data)){
						unset($data['password']);
						//unset($data['provider_uid']);
						$data['type']='social';
						$loginData = $this->makeLogin($data);
						$data['user_id']= $loginData['user_id'];
						$data['access_token'] = $loginData['access_token'];
 						$response['status'] = true;
 						$response['msg'] = "User created successfully";
						$response['data'] = $data;
						$response['code']=200;
						$this->sendOtpUser($data);
 					} else {
 						$response['msg'] = "Some error Occured.";
						$response['code']=500;
 					}
 					$this->response($response,200);
 				}
 }

 /******************************
	Method to send and resend otp to verify Mobile
 *********************************/
 public function send_otp_post()
 {
	$user_id = $this->auth_check();
	$userDetails = $this->user_model->getUserById($user_id);
	$response['status'] = false;
 	$username = $userDetails['user_name'];
	$email = $userDetails['email'];
	$resend = $this->post('resend');
	$sendTo = $this->post('send_to');//1 for mobile 2 for email 3 for both
	//$mobile = $this->post('mobile');
	//$countryCode = $this->post('country_code');
	 if (empty($sendTo)) {
	 	$response['msg'] = "Please provide valid send_to  option.";
	 	$response['code']=400;
	 	return $this->response($response,REST_Controller::HTTP_BAD_REQUEST);
	 }
	//get mobile no and country_code from users table
	//$data = $this->checkuser_model->getMobile(['username'=>$username, 'email'=>$email]);
	//if (is_array($data)) {
		$countryCode = $userDetails['country_code'];
		$mobile	= $userDetails['mobile'];

		//Now generate new otp ,insert into otp_master and send OTP to mobile
		//$otp = getToken(4); //for later use
		$otp ='1234';
		$otpData = [
			'user_id' => $userDetails['user_id'],
			'otp' => $otp,
			'mobile' => $mobile,
			'otp_type' => $sendTo
		];
		if($resend!=1){
			$otpStatus = $this->otp_model->sendOtp($otpData);
		}else {
			$otpStatus = $this->otp_model->resendOtp($otpData);//will return otp or false on failure
			$otp = $otpStatus;
		}
			if ($otpStatus!==false) { //otp has been inserted then send it to user
				switch ($sendTo) {
					case '1':
						//send otp over mobile phone
						break;
					case '2':
							//send deep link to emailid
						break;
					case 3 :
						//send an sms and deep link to mobile and email id respectively
					 break;
					default:
					$response['status']=true;
					$response['msg'] = "Invalid option to send otp";
					$response['code']=400;
					return $this->response($response,REST_Controller::HTTP_OK);
				}
				$response['status']=true;
				$response['msg'] = "An OTP Has Been Sent  Valid for 10 minuts.";
				$response['code']=200;
				return $this->response($response,REST_Controller::HTTP_OK);
			} else {
				$response['code']=404;
				$response['status']=false;
				$response['msg'] = "Some Error Occured";
				return $this->response($response,REST_Controller::HTTP_NOT_FOUND);
			}
		// } else {
		// 	$response['msg']= "Mobile Not found";
		// 	$response['code']=404;
		// 	return $this->response($response, REST_Controller::HTTP_NOT_FOUND);
		// }
 }

/**********************************************
Method to verify otp
***********************************************/
public function verifyotp_post()
{
	$user_id = $this->auth_check();
	$userDetails = $this->user_model->getUserById($user_id);
	$response['status'] = false;
 	$username = $userDetails['user_name'];
	$email = $userDetails['email'];
	$otp = $this->post('otp');
	$otpType = $this->post('send_to');//1:mobile 2: emailid and 3: for both
	// if (empty($username) && empty($email)) {
	// 	$response['msg'] = "Please provide username or email.";
	// 	$response['code']=400;
	// 	return $this->response($response,REST_Controller::HTTP_BAD_REQUEST);
	// }
	if (empty($otp) || empty($otpType)) {
		$response['msg'] = "OTP /  Send to is empty";
		$response['code']=400;
		return $this->response($response,REST_Controller::HTTP_BAD_REQUEST);
	}
	//get mobile no and country_code from users table
	//$data = $this->checkuser_model->getMobile(['username'=>$username, 'email'=>$email]);
	//print_r($data);
	//if (is_array($data)) {
		$countryCode = $userDetails['country_code'];
		$mobile	= $userDetails['mobile'];
		//send otp to model to check whether it exists or not
		$otpData = [
			'user_id' => $userDetails['user_id'],
			'otp' => $otp,
			'otp_type' => $otpType,
			'mobile' => $mobile
		];
		//print_r($otpData);
		$otpVerifyStatus = $this->otp_model->verifyOtp($otpData);
		//var_dump($otpVerifyStatus);
		if($otpVerifyStatus ===true){
			$response['status'] = true;
			$response['msg'] = "OTP Verified successfully";
			$userDetails['access_token'] = $userDetails['access_key'];
			unset($userDetails['access_key']);
			$response['data'] = $userDetails;
			$response['code']=200;
			return $this->response($response,200);
		} else {
			$response['msg'] = "Invalid or Expired OTP";
			$response['code']=404;
			return $this->response($response,REST_Controller::HTTP_NOT_FOUND);
		}
	// }  else {
	// 	$response['msg']= "Mobile Not found";
	// 	$response['code']=404;
	// 	return $this->response($response, REST_Controller::HTTP_NOT_FOUND);
	// }
}
/*******************************
Method to send username over email address

**********************************/
public function forget_username_post()
{
	$response['status'] = false;
	$email = $this->post('email');
	//validate Email
	if (filter_var($email, FILTER_VALIDATE_EMAIL) === FALSE) {
		$response['msg'] = "Invalid Format of Email";
		$response['code']=400;
		return $this->response($response,REST_Controller::HTTP_BAD_REQUEST);
	}
	//now get user's username from database
	$userData = $this->checkuser_model->getUserName(['email'=>$email]);
	if ($userData !== false) {
		//send username over email address of the user

		$userName = $userData['user_name'];
		$response['status'] = true;
		$response['msg'] = "User Name has been sent to email address please check your email inbox.";
		$response['code']=200;
		$emailMsg = "Your user name is $userName";
		sendMail($emailMsg,"Surface",$email);
		return $this->response($response,200);
	} else {
		$response['msg'] = "Email Not Found";
		$response['code']=404;
		return $this->response($response,404);
	}
}

/********************************************
Method to recieve forget password requests
it may recive an email id or mobile no of user
it will check existance of the user and will send a deep link over given mobile or email
to reset user's password
***********************************************/
public function forget_password_post()
{
	$response['status'] = false;
	$email = $this->post('email');
	$mobile = $this->post('mobile');
	$country_code = $this->post('country_code');
	if (empty($email) && empty($mobile)) {
		$response['msg'] = "Invalid Request";
		$response['code'] = 400;
		return $this->response($response,$response['code']);
	}
	if (!empty($email) && filter_var($email, FILTER_VALIDATE_EMAIL) === FALSE){
		$response['msg'] = "Invalid EMAIL";
		$response['code'] = 400;
		return $this->response($response,$response['code']);
	}
	if (!empty($email)) {
		$data['email'] = $email;
	} else {
		$data['mobile'] = $mobile;
	}

	$userStatus = $this->checkuser_model->getUserName($data);
	if ($userStatus !== false) {
		//create deep link
		$response['status'] = true;
		//$response['user_id'] = encrypt_decrypt('encrypt',$userStatus['user_id']);
		$response['code'] = 200;
		$baseLink = base_url('/reset_password/');
		$userData = "user_id:".$userStatus['user_id']."#user_name:".$userStatus['user_name']."#time:".time();
		$encryptedData = encrypt_decrypt('encrypt',$userData);
		$urlSc = $baseLink."?token=".$encryptedData;
		reset($data);
		switch(key($data)){
			case 'email':
				//send an link over email to reset password
				$emailMsg = "To reset your password   <a href='$urlSc' alter='password reset link' target='_blank'>Click Here</a> ";
				sendMail($emailMsg,"Surface Password Reset",$email);
				$response['msg'] = "An Email  has been sent to ".$data['email']." with password reset link ";
			break;
			case 'mobile':
				// send the password reset OTP over sms to reset password
				//$otp = getToken(4); //for later use
				$otp ='1234';
				$otpData = [
					'user_id' => $userStatus['user_id'],
					'otp' => $otp,
					'mobile' => $mobile,
					'otp_type' => 4  // 4 for password reset
				];
				$otpStatus = $this->otp_model->sendOtp($otpData);
				$response['msg'] = "An OTP  has been sent to ".$data['mobile'];
				break;
			default:
				$response['status'] = true;
				$response['code'] = 400;
				$response['msg'] = "Invalid Request";
		}
		return $this->response($response,$response['code']);
	} else {
		$response['msg'] = 'User does not exists with given details.';
		$response['code'] = 404;
		return $this->response($response,$response['code']);
	}

}
/****************************
Method to reset password of a user
an encrypted token has been send to user in format
user_id:ID#user_name:username#time:timestamp
1: decrypt tokens
2: validate it
3: reset password if token is valid
****************************/
public function reset_password_post()
{
	$response['status']=false;
	$token = $this->post('token');
	$sendTo = $this->post('send_to');// 1:Mobile 2: email 3:both
	$mobile = $this->post('mobile'); //mobile no is required if send_to type is 1;
	$password = $this->post('password');
	if(empty($token) || empty($password) ){
		$response['msg'] = "Invalid Request";
		$response['code'] = 400;
		return $this->response($response,$response['code']);
	}
	if ($sendTo ==1) { //verify otp
		if (empty($mobile)) {
			$response['msg'] = "Mobile no field is empty";
			$response['code'] = 400;
			return $this->response($response,$response['code']);
		} else {
			//token is otp and password mobile
			//get userdetails based on mobile
			$usersdata = $this->user_model->getUserByMobile($mobile);
			if (is_array($usersdata)) {
				//verify otp
				$details =[ 'user_id' => $usersdata['user_id'],
				'mobile' => $mobile,
				'otp'       => $token,
				'otp_type' => 4
				];
				$otpStatus = $this->otp_model->verifyOtp($details);
				if ($otpStatus) {
					//now you can change password
					$updateStatus = $this->user_model->updateUser($usersdata['user_id'],['password'=>md5($password)]);
					if ($updateStatus) {
						$response['status'] = true;
						$response['msg']="Password Reset Successfully";
						$response['code'] = 200;
						return $this->response($response,$response['code']);
					}else {
						$response['msg']="Some Error Occured";
						$response['code'] = 500;
						return $this->response($response,$response['code']);
					}
				}
			}
			$response['msg']="Invalid OTP or Mobile";
			$response['code'] = 400;
			return $this->response($response,$response['code']);
		}

	}
	//get user_id and user_name from tokens
	$unencryptedToken = encrypt_decrypt("decrypt",$token);
	$userD= explode("#",$unencryptedToken);
	$userData = array();
	foreach($userD as $val){
		list($name,$value)=explode(":",$val);
		$userData[$name]=$value;
	}

	//check validity if it is before 10 minutes
	if(!empty($userData['user_id']) && !empty($userData['user_name']) && !empty($userData['time'])){
		//check token validity
		//var_dump($userData);
		if ($userData['time'] >= (time()-86400)) { //validity 10 minutes only
			//now find user and reset password.if user Found
			$userDetails = $this->user_model->getUserById($userData['user_id']);
			if ($userDetails !==false) {
				//now update user password
				$updateStatus = $this->user_model->updateUser($userData['user_id'],['password'=>md5($password)]);
				if ($updateStatus) {
					$response['status'] = true;
					$response['msg']="Password Reset Successfully";
					$response['code'] = 200;
					return $this->response($response,$response['code']);
				}else {
					$response['msg']="Some Error Occured";
					$response['code'] = 500;
					return $this->response($response,$response['code']);
				}
			}
		}
	}
		$response['msg']="Invalid Token";
		$response['code'] = 400;
		return $this->response($response,$response['code']);

}
/*********************************
Method to login a user using userName/email/mobile and password
It will recieve user name and password and

*********************************/
public function login_post()
{
	$response['status'] = false;
	$loginDetails['user_name'] = $this->post('username');// it can be user_name, email or mobile
	//$loginDetails['email'] = $this->post('email');
	//$loginDetails['mobile'] = $this->post('mobile');
	$loginDetails['password'] = $this->post('password');
	$loginDetails['type'] = "app";
	if (empty($loginDetails['user_name']) ) {
		$response['msg'] = "User Name or email or mobile no is not present";
		$response['code'] = 400;
		return $this->response($response,$response['code']);
	}
	if (empty($loginDetails['password'])) {
		$response['msg'] = "Password required";
		$response['code'] = 400;
	}
	$loginStatus = $this->makeLogin($loginDetails);
	if ($loginStatus !== false) {
		$response['status'] = true;
		$response['code'] = 200;
		$response['data'] = $loginStatus;
		return $this->response($response,$response['code']);
	} else {
		$response['msg'] = "Login Failed";
		$response['code'] = 400;
		return $this->response($response,$response['code']);
	}
}
/*********************************************
Method to logout
It will recive access token and willl clear it from database



********************************************/
public function logout_post()
{

	//$user_id = $this->auth_check();
	$response['status'] = false;
	//if ($this->user_model->logout($user_id)) {
		$response['status'] = true;
		$response['msg'] = "User Has Been Logged Out.";
		$response['code'] = 200;
		return $this->response($response,$response['code']);
	// }
	// $response['msg'] = "Logout failed";
	// $response['code'] = 500;
	// return $this->response($response,$ressponse['code']);
}
/********************
Method to login users
It will recive username or email or mobile no as username with password for standard users
For users logged in through Social media it will recive only provider_uid and provider
It will generate an access token of 32 character long and will revert it with user's profile.

***********************/
public function makeLogin(array $data)
{
//print_r($data);

	if (empty($data['user_name']) && empty($data['email']) && empty($data['mobile'])) {
		return false;
	} else {
		if(empty($data['password']) && $data['type']!='social'){
			return false;
		} else {
			//now check and Login
			$loginStatus = $this->checkuser_model->checkandLogin($data);
			if(is_array($loginStatus)){
				return $loginStatus;
			} else {
				return false;
			}
		}
	}
}

/***********
Method to send otp to mobile and emailid
after signup of user.
**************/
public function sendOtpUser(array $data)
{
	//print_r($data);
	$otp ='1234';//will be changed later
	$otpData = [
		'user_id' => $data['user_id'],
		'otp' => $otp,
		'mobile' => $data['mobile'],
		'otp_type' => 3
	];

		$otpStatus = $this->otp_model->sendOtp($otpData);
	//var_dump($otpStatus);
}
/****************
Method to authenticate access token for a user

**/
public function auth_check()
{

	if (isset($_SERVER['HTTP_ACCESS_TOKEN']) && !empty($_SERVER['HTTP_ACCESS_TOKEN'])) {
		//echo 'Token:'.$_SERVER['HTTP_ACCESS_TOKEN'];
		//get user_id based on data
		$user_id = false;
		$token = $_SERVER['HTTP_ACCESS_TOKEN'];
		$this->load->model('token_model');
		$userId = $this->token_model->check_token($token);
		if (is_array($userId)) {
		  $user_id = $userId['user_id'];
			return $user_id;
		}

	}
	$response['status']=false;
	$response['msg']= 'Unauthorized Access';
	$response['code'] = 401;
	return $this->response($response,$response['code']);

}
}

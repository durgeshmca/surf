<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require APPPATH . 'libraries/REST_Controller.php';
/*
This class is responsible to add / edit/delete posted by users
This will only be available to authenticated users
*******/
class Posts extends REST_Controller{
  private $user_id; //user_id of the user using the class it is mandatory
  public function __construct()
  {
    parent::__construct();
    //load auth library
    $this->load->library('authenticate');
    $this->user_id = $this->authenticate->auth_check();
    $this->load->model('user_model');
    $this->load->model('post_model');
    //$this->load->helper('send_mail');
  }
  /****
  default page is 20 posts
  Method to list posts
  if id is present then will response only given post
  if page field is present then start from (page-1 *20 ) + 1 To (page -1)* 20 + 20 post
  ******************/
  function index_get()
  {
    $response['status'] = false;
    $id=$this->get('id'); //post id
    $page = $this->get('page');
    if (empty($id))
    {
      if (empty($page) or $page < 1) {
        $page = 1;
      }
      $offset = ($page -1) * 20; //20 default
      $postData = $this->post_model->listPost($this->user_id,$offset);
        // Check if the users data store contains users (in case the database result returns NULL)
        if (is_array($postData))
        {
            $response['status'] = true;
            $response['msg'] = 'Post Listing successfull';
            $response['code'] = 200;
            $response['data'] = $postData['data'];
            $response['total'] = $postData['total'];
            $this->response($response, REST_Controller::HTTP_OK); // OK (200) being the HTTP response code
        }
        else
        {
            // Set the response and exit
            $this->response([
                'status' => FALSE,
                'message' => 'No post were found'
            ], REST_Controller::HTTP_NOT_FOUND); // NOT_FOUND (404) being the HTTP response code
        }
    }

    $id = (int) $id;

    // Validate the id.
    if ($id <= 0)
    {
      $response['msg'] = "Invalid Request";
      $response['code'] = 400;
        // Invalid id, set the response and exit.
        $this->response($response, REST_Controller::HTTP_BAD_REQUEST); // BAD_REQUEST (400) being the HTTP response code
    }

    $postData = $this->post_model->listPost($this->user_id,0,$id);



    if (!empty($postData))
    {
      $response['status'] = true;
      $response['msg'] = 'Post Listing successfull';
      $response['code'] = 200;
      $response['data'] = $postData['data'];
      $response['total'] = $postData['total'];
      $this->response($response, REST_Controller::HTTP_OK); // OK (200) being the HTTP response code
    } else {
        $this->set_response([
            'status' => FALSE,
            'message' => 'post could not be found',
            'code' =>404
        ], REST_Controller::HTTP_NOT_FOUND); // NOT_FOUND (404) being the HTTP response code
    }
  }
  /*****************
  Method to add post
  */
  public function add_post()
  {
    $userDetails = $this->user_model->getUserById($this->user_id);
    //print_r($userDetails);
    //validate data in post all fields are optional
    //print_r($this->post());
    $response['status'] = false;
    $user_name = $userDetails['user_name'];
    $desc = $this->post('description');
    $media = $this->post('media');
    $location = $this->post('location');
    $longitude = $this->post('longitude');
    $lattitude = $this->post('lattitude');
    $tags = implode(',',$this->post('tags'));
    if (is_array($media) && count($media) > 0) { //array is not empty
      $media = json_encode($media);
    }
    $postData = [
      'user_id' => $this->user_id,
      'user_name' => $user_name,
      'description'=> $desc,
      'media' => $media,
      'location' => $location,
      'longitude' => $longitude,
      'lattitude' => $lattitude,
      'tags' => $tags
    ];
    $postStatus = $this->post_model->addPost($postData);
    if ($postStatus) {
      $response['status'] = true;
      $response['msg'] = "Post Added Successfully";
      $response['code'] = 200;
      return $this->response($response,$response['code']);
    }
    $response['msg'] = "Could not add post";
    $response['code'] = 500;
    return $this->response($response,$response['code']);
  }
  /*
  Method to update post will recieve a post id
  ****************/
  public function update_post()
  {
    $userDetails = $this->user_model->getUserById($this->user_id);
    //print_r($userDetails);
    //validate data in post all fields are optional
    //print_r($this->post());die;
    $response['status'] = false;
    $user_name = $userDetails['user_name'];
    $post_id = $this->post('id');
    $desc = $this->post('description');
    $media = $this->post('media');
    $location = $this->post('location');
    $longitude = $this->post('longitude');
    $lattitude = $this->post('lattitude');
    $tags = implode(',',$this->post('tags'));
    if (empty($post_id)) { //id field is necessary
      $response['msg'] = 'Post id is not present';
      $response['code'] = 400;
      return $this->response($response,$response['code']);
    }
    if (is_array($media) && count($media) > 0) { //array is not empty
      $media = json_encode($media);
    }else {
      $media ='';
    }
    $postData = [
      'user_id' => $this->user_id,
      'user_name' => $user_name,
      'description'=> $desc,
      'media' => $media,
      'location' => $location,
      'longitude' => $longitude,
      'lattitude' => $lattitude,
      'tags' => $tags
    ];
    $postStatus = $this->post_model->updatePost($post_id,$postData);
    if ($postStatus) {
      $response['status'] = true;
      $response['msg'] = "Post updated Successfully";
      $response['code'] = 200;
      return $this->response($response,$response['code']);
    }
    $response['msg'] = "Could not update post";
    $response['code'] = 500;
    return $this->response($response,$response['code']);
  }
  public function delete_post()
  {
    $response['status'] = false;
  //  $id =$this->get('id');
    //var_dump($id);
    $id =$this->post('id');
    //var_dump($id);die;
    $id = (int) $id;
    // Validate the id.
    if ($id <= 0)
    {
      $response['msg'] = "Invalid Request";
      $response['code'] = 400;
        // Invalid id, set the response and exit.
        $this->response($response, REST_Controller::HTTP_BAD_REQUEST); // BAD_REQUEST (400) being the HTTP response code
    }
    //now delete the post
    if($this->post_model->deletePost($this->user_id,$id)){
      $response['status'] = true;
      $response['msg'] = "Post deleted Successfully";
      $response['code'] = 200;
      return $this->response($response,$response['code']);
    }
    //$response['status'] = true;
    $response['msg'] = "Post not found ";
    $response['code'] = 404;
    return $this->response($response,$response['code']);
  }
}

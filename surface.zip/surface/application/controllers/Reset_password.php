<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Reset_password extends CI_Controller {


	public function index()
	{
  $token = $this->input->get('token');

		$this->load->view('deeplink',array('token'=>$token));
	}
}

<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_model extends CI_Model{

  public function __construct()
  {
    //parent::__construct();
    $this->load->database();
  }
  public function checkLogin($email,$password)
  {
    $this->db->where([
      'email'=>$email,
      'password' => md5($password)
    ]);
    $query = $this->db->get('login');
    if ($query->num_rows()>0) {
      return $query->row_object();
    }
    return false;
  }
  /****
  validate email of admin
  *******/
  public function getUserByEmail($email)
  {
    $this->db->select(['id','name','user_name','email','mobile']);
    $this->db->where('email',$email);
    $query = $this->db->get('login');
    if ($query->num_rows()>0) {
      return $query->row_array();
    }
    return false;
  }
  /****
  Update Admin password
  *****/
  public function updatePassword($id,$password)
  {
    $data['password'] = md5($password);
    $this->db->where('id',$id);
    if ($this->db->update('login',$data)) {
      return true;
    }
    return false;
  }
  /***
  method to list users with pagging
**********/
  public function listUsers($offset = 0,$limit = 20,$search='')
  {


    if (!empty($search)) {
      $this->db->like('name',$search)
                ->or_like('user_name',$search)
                ->or_like('email',$search);
      $data['total'] = $this->db->count_all_results('Users');
      $this->db->like('name',$search)
                ->or_like('user_name',$search)
                ->or_like('email',$search);
    }else{
      $data['total'] = $this->db->count_all('Users');
    }
    $this->db->select(['user_id','name','email','location','user_name','posts_count','created_at','status']);
    $this->db->limit($limit,$offset);
    $query = $this->db->get('Users');
    //echo $this->db->last_query(); die;
    $data['data'] = $query->result_array();
    unset($data['data']['password']);
    unset($data['data']['access_key']);
    return $data;
  }
  /*******
  Get All Profile Information for a user like
  User Profile
  ***********/
  public function getUserProfile($id='')
  {
    if (!empty($id)) {
      $data = array();
      $this->db->select(['user_id','name','email','location','user_name','created_at','status']);
      $this->db->where('user_id',$id);
      $query = $this->db->get('Users');
      //echo $this->db->last_query(); die;
      $data['profile'] = $query->row_array();
      if ($query->num_rows()>0) {
        return $data;
      } else {
        return false;
      }
    }
  }

  //Method to block a user
  public function blockUser($user_id,$status)
  {
    $this->db->where('user_id',$user_id);
    return $this->db->update('users',['status' => $status]);
  }
 public function changeAdminPassword($id,$oldp,$new)
 {
   $this->db->where([
     'id'=>$id,
     'password' => md5($oldp)
   ]);
  if($this->db->update('login',['password'=>md5($new)])){
    return true;
  }
   return false;
 }
}

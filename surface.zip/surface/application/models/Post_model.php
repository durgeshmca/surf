<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Post_model extends CI_Model{

  public function __construct()
  {
    //parent::__construct();
    $this->load->database();
  }

  public function addPost(array $data)
  {
    $this->db->set('created_at','NOW()',false) ;
    $this->db->set('updated_at','NOW()',false) ;
    if ($this->db->insert('posts',$data)) {
      return true;
    }
    return false;
  }
  public function updatePost($post_id,array $data)
  {
    //$this->db->set('created_at','NOW()',false) ;
    $this->db->set('updated_at','NOW()',false) ;
    $this->db->where('id',$post_id);
    if ($this->db->update('posts',$data)) {
      return true;
    }
    return false;
  }
  public function listPost($user_id,$offset,$id='')
  {
    $this->db->where('user_id',$user_id);//to count no of post of the user
    $this->db->from('posts');
    $total = $this->db->count_all_results();
    if ($id=='') {
      $this->db->limit(20,$offset);
      $this->db->order_by('created_at','DESC');
    } else {
      $this->db->where('id',$id);
    }
    $this->db->where('user_id',$user_id);

    $query = $this->db->get('posts');
    //echo $this->db->last_query(); die;
    $total = $this->db->count_all('posts');
    if ($query->num_rows()>0) {
      $data['data'] = $query->result_array();
      $data['total'] = $total;
      return $data;
    }
    return false;
  }
  public function deletePost($user_id,$post_id)
  {


    $this->db->where(['id'=>$post_id,'user_id'=>$user_id]);
    $this->db->from('posts');
    $total = $this->db->count_all_results(); // find if exists
    $this->db->where(['id'=>$post_id,'user_id'=>$user_id]);
    $this->db->delete('posts');
    //echo $this->db->last_query();
    return $total;
  }
}

<?php
/**
 * model to get token and clear token
 */
class Token_model extends CI_Model
{

  function __construct()
  {
    $this->load->database();
  }
  public function check_token($accessToken)
  {
    if ($accessToken!='') {
    $this->db->select('user_id');
    $this->db->where('access_key',$accessToken);
    $query = $this->db->get('Users');
    //echo $this->db->last_query();
    if($query->num_rows()>0){
      return $query->row_array();
    } else {
      return false; //token invalid or unauthorised
    }
    }
  }

}

<?php

class Otp_model extends CI_Model {

    public function __construct()
    {
        $this->load->database();
    }

    public function sendOtp($data)
    {
      $insertData = [
        'user_id' => $data['user_id'],
        'otp' => $data['otp'],
        'otp_type' => $data['otp_type'],
        'mobile_no' => $data['mobile'],
        'created_at' => date('Y-m-d H:i:s'),
        'validity' => date('Y-m-d H:i:s',time()+600),
        'verify_status' => 0
      ];
      if($this->db->insert('otp_master',$insertData)){
      //  echo $this->db->last_query();
        return true;
      } else {
        echo $this->db->last_query();
        return false;
      }
    }
    public function resendOtp($data)
    {
      //get otp sent recenty
      $this->db->select(['id','otp'])
                ->where([
                  'user_id' => $data['user_id'],
                  'mobile_no' => $data['mobile'],
                  'otp_type' => $data['otp_type'],
                  'validity > ' => date('Y-m-d H:i:s',time())
                ])
              ->order_by('validity','DESC')
              ->limit(1);
      $query= $this->db->get('otp_master');
      if ($query->num_rows() > 0) {
        $otp = $query->row_array();
        //increase validity by 10 minutes
        $this->db->set([
          'validity' => date('Y-m-d H:i:s',time()+600)
        ]);
        $this->db->where('id',$otp['id']);
        $this->db->update('otp_master');
        return $otp['otp'];
      } else {
      //otp not found
        $insertData = [
          'user_id' => $data['user_id'],
          'otp' => $data['otp'],
          'otp_type' => $data['otp_type'],
          'mobile_no' => $data['mobile'],
          'created_at' => date('Y-m-d H:i:s'),
          'validity' => date('Y-m-d H:i:s',time()+600),
          'verify_status' => 0
        ];
      if($this->db->insert('otp_master',$insertData)){
      //  echo $this->db->last_query();
          return $data['otp'];
        } else {
          //echo $this->db->last_query();
          return false;
        }
      }

    }

    //method to verify otp_model
    public function verifyOtp($data)
    {
      $this->db->select(['id','otp','verify_status'])
                ->where([
                  'user_id' => $data['user_id'],
                  'mobile_no' => $data['mobile'],
                  'otp'       => $data['otp'],
                  'otp_type' => $data['otp_type'],
                //  'validity > ' => date('Y-m-d H:i:s',time())
                ])
              ->order_by('validity','DESC')
              ->limit(1);
      $query= $this->db->get('otp_master');
      if ($query->num_rows() > 0) {
        $otpData = $query->row_array();

        $this->db->set([
          'verify_status' => 1
        ]);
        $this->db->where('id',$otpData['id']);
        $this->db->update('otp_master');
        return true;
      } else {
        return false;
      }
    }
}

<?php
class Checkuser_model extends CI_Model {

    public function __construct()
    {
        $this->load->database();
    }

    public function check(array $data)
        {
        	if (empty($data) ) {
        		return false;
        	}
        	//print_r($data);
        	$whereArray = array();
        	$this->db->select('user_id');
        	if(array_key_exists('username', $data)){
        		$this->db->or_where('user_name' , $data['username']);
        	}
        	if(array_key_exists('email', $data)){
        		$this->db->or_where('email' , $data['email']);
        	}
        	if(array_key_exists('mobile', $data)){
        		$this->db->or_where('mobile' , $data['mobile']);
        	}


        	$this->db->or_where($whereArray);
        	$query = $this->db->get('Users');
        	//echo $this->db->last_query();
        	// if (count($query->row_object())> 0) {
        	// 	return 1; //if a user exists
        	// }
         	if($query->num_rows() > 0) {
         		return true;
         	} else {
         		return false;
         	}
      	}
        public function check_social($provider, $uid)
        {
          $this->db->select(['user_id','name','user_name','email','country_code','mobile','created_at','updated_at','access_key as access_token']);
          $this->db->where(array(
            'provider'=>$provider,
            'provider_uid' => $uid
          ));
          $query = $this->db->get('Users');
          //echo $this->db->last_query();
          if($query->num_rows() > 0) {
         		return $query->row_array();
         	} else {
         		return false;
         	}
        }

        public function getMobile(array $userData)
        {
          $this->db->select(['user_id','country_code','mobile']);
          if (!empty($userData['username'])) {
            $this->db->where('user_name',$userData['username']);
          } else {
            $this->db->where('user_name',$userData['email']);
          }
          $query = $this->db->get('Users');
          //echo $this->db->last_query();
          if($query->num_rows() > 0) {
         		return $query->row_array();
         	} else {
         		return false;
         	}
        }
        public function getUserName(array $data) //data may be email or mobile
        {
          $this->db->select(['user_id','user_name','email','country_code','mobile']);
          if(!empty($data['email'])){
            $this->db->where('email',$data['email']);
          } elseif(!empty($data['mobile'])) {
            $this->db->where('mobile',$data['mobile']);
          } else {
            return false;
          }
          $query = $this->db->get('Users');
          if ($query->num_rows()>0) {
            return $query->row_array();
          } else {
            return false;
          }
        }
      /* check login credential and make user login revert with user details and access token on success */
      public function checkandLogin(array $data)
      {
      //  print_r($data);die;
        $this->db->select(['user_id','user_name','email','country_code','mobile','created_at','updated_at']);
        if (!empty($data['user_name']) && $data['type']!='social') {
          $this->db->where('(email ="'.$data['user_name'].'" OR user_name = "'.$data['user_name'].'" OR mobile = "'.$data['user_name'].'")');

        }else{
          if(!empty($data['email'])){
            $this->db->where('email',$data['email']);
          } elseif(!empty($data['mobile'])) {
            $this->db->where('mobile',$data['mobile']);
          } else {
            $this->db->where('user_name',$data['user_name']);
          }
        }
        if($data['type']!='social'){
        $this->db->where('password',md5($data['password']));
      } else{
        $this->db->where(['provider'=>$data['provider'],'provider_uid'=>$data['provider_uid']]);
      }
        $query = $this->db->get('Users');
        //echo $this->db->last_query(); die;
        if ($query->num_rows()> 0) {
          $queryData = $query->row_array();
        //  $token = getToken(32);
          $token = md5($queryData['user_id'].time());
          $this->db->where('user_id',$queryData['user_id']);
          if($this->db->update('Users',['access_key'=>$token])){
            //echo $this->db->last_query();
            $queryData['access_token'] = $token;
            return $queryData;
          } else {
            //echo $this->db->last_query();
            return false;
          }
        } else{
          return false;
        }
      }
}

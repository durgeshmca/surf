<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_model extends CI_Model{

  public function __construct()
  {
    parent::__construct();
    $this->load->database();

  }

  /******************
  method to get user details based on user_id of the user

  ********************/
  public function getUserById($user_id)
  {
    $this->db->select(['user_id','name','user_name','email','mobile','country_code','provider','provider_uid','access_key','created_at','updated_at']);
    $this->db->where('user_id',$user_id);
    $query = $this->db->get('Users');
  //  echo $this->db->last_query();
    if ($query->num_rows()> 0) {
      $data = $query->row_array();
      $data['access_token'] = $data['access_key'];
      return $data;
    } else {
      return false;
    }
  }
  /***********
  Method to update user's data it will recive user_id and data to update in an array
  */

/****************
  Method to logout user
*/
public function logout($user_id)
{
  if (!empty($user_id)) {
    $this->db->where('user_id',$user_id);
    $data = [
      'access_key' => ''
    ];
    if($this->db->update('Users',$data)){
      return true;
    }
  }
  return false;
}
/******************
Method to update user profile or data
updateUser($userData['user_id'],['password'=>$password])
*****************/
public function updateUser($user_id,array $data)
{
  if (!empty($user_id)) {
    $this->db->where('user_id',$user_id);
    if($this->db->update('Users',$data)){
      return true;
    }
  }
  return false;
}
/******************
method to get user details based on mobile of the user

********************/
public function getUserByMobile($mobile)
{
  $this->db->select(['user_id','name','user_name','email','mobile','country_code','provider','provider_uid','access_key','created_at','updated_at']);
  $this->db->where('mobile',$mobile);
  $query = $this->db->get('Users');
//  echo $this->db->last_query();
  if ($query->num_rows()> 0) {
    $data = $query->row_array();
    $data['access_token'] = $data['access_key'];
    return $data;
  } else {
    return false;
  }
}


}
